import { serve } from "https://deno.land/std@0.205.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const AI_MODEL = "google/gemini-2.5-flash";

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type AnalyzeRequest = {
  userId: string;
  text?: string;
  files?: string[];
  checklist?: Record<string, boolean>;
  isOcrExtracted?: boolean;
};

type CorporatePattern = {
  industry: string;
  common_phrases: string;
  tone: string;
  risk_baseline: number;
};

type StealthSignature = {
  attack_type: string;
  linguistic_markers: string;
  psychological_pattern: string;
  common_phrases: string;
  risk_weight: number;
};

type ExplanationEntry = {
  risk_level: string;
  category: string;
  explanation_text: string;
  recommended_action: string;
};

type ThreatMemory = {
  id: string;
  normalized_pattern: string;
  risk_outcome: string;
  frequency: number;
};

// Normalize text for pattern matching
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 500);
}

// Calculate similarity between two strings (simple Jaccard-like)
function calculateSimilarity(text1: string, text2: string): number {
  const words1 = new Set(text1.toLowerCase().split(/\s+/));
  const words2 = new Set(text2.toLowerCase().split(/\s+/));
  const intersection = new Set([...words1].filter(x => words2.has(x)));
  const union = new Set([...words1, ...words2]);
  return union.size > 0 ? intersection.size / union.size : 0;
}

// Fetch intelligence context from database
async function fetchIntelligenceContext(text: string) {
  console.log("Fetching intelligence context from database...");
  
  const [corporateRes, stealthRes, explanationsRes, datasetRes] = await Promise.all([
    supabase.from("corporate_pattern_library").select("*").limit(20),
    supabase.from("stealth_phishing_signatures").select("*"),
    supabase.from("explainable_security_library").select("*"),
    supabase.from("security_message_dataset").select("message_text, risk_level, risk_score, category, rationale").limit(50)
  ]);

  const corporatePatterns: CorporatePattern[] = corporateRes.data || [];
  const stealthSignatures: StealthSignature[] = stealthRes.data || [];
  const explanations: ExplanationEntry[] = explanationsRes.data || [];
  const datasetExamples = datasetRes.data || [];

  // Find most relevant patterns based on text similarity
  const normalizedInput = normalizeText(text);
  
  // Match against stealth signatures
  let stealthMatches: { signature: StealthSignature; score: number }[] = [];
  for (const sig of stealthSignatures) {
    const phrases = sig.common_phrases.toLowerCase();
    const markers = sig.linguistic_markers.toLowerCase();
    const similarity = Math.max(
      calculateSimilarity(normalizedInput, phrases),
      calculateSimilarity(normalizedInput, markers)
    );
    if (similarity > 0.1) {
      stealthMatches.push({ signature: sig, score: similarity });
    }
  }
  stealthMatches.sort((a, b) => b.score - a.score);

  // Match against corporate patterns
  let corporateMatches: { pattern: CorporatePattern; score: number }[] = [];
  for (const pat of corporatePatterns) {
    const phrases = pat.common_phrases.toLowerCase();
    const similarity = calculateSimilarity(normalizedInput, phrases);
    if (similarity > 0.1) {
      corporateMatches.push({ pattern: pat, score: similarity });
    }
  }
  corporateMatches.sort((a, b) => b.score - a.score);

  // Find similar dataset examples
  let relevantExamples: typeof datasetExamples = [];
  for (const ex of datasetExamples) {
    const similarity = calculateSimilarity(normalizedInput, ex.message_text);
    if (similarity > 0.15) {
      relevantExamples.push(ex);
    }
  }
  relevantExamples = relevantExamples.slice(0, 10);

  return {
    corporatePatterns: corporateMatches.slice(0, 3).map(m => m.pattern),
    stealthSignatures: stealthMatches.slice(0, 5).map(m => m.signature),
    explanations,
    relevantExamples
  };
}

// Fetch user's personal threat memory
async function fetchUserThreatMemory(userId: string, text: string): Promise<ThreatMemory[]> {
  const normalizedPattern = normalizeText(text);
  
  const { data } = await supabase
    .from("personal_threat_memory")
    .select("*")
    .eq("user_id", userId)
    .limit(20);
  
  if (!data || data.length === 0) return [];
  
  // Find similar patterns from user's history
  const matches: ThreatMemory[] = [];
  for (const memory of data) {
    const similarity = calculateSimilarity(normalizedPattern, memory.normalized_pattern);
    if (similarity > 0.2) {
      matches.push(memory);
    }
  }
  
  return matches.slice(0, 5);
}

// Update user's personal threat memory
async function updateUserThreatMemory(userId: string, text: string, riskLevel: string, category: string) {
  const normalizedPattern = normalizeText(text);
  const riskOutcome = `${riskLevel}:${category}`;
  
  // Check if similar pattern exists
  const { data: existing } = await supabase
    .from("personal_threat_memory")
    .select("*")
    .eq("user_id", userId)
    .limit(100);
  
  let foundMatch = false;
  if (existing) {
    for (const memory of existing) {
      const similarity = calculateSimilarity(normalizedPattern, memory.normalized_pattern);
      if (similarity > 0.5) {
        // Update existing pattern
        await supabase
          .from("personal_threat_memory")
          .update({
            frequency: memory.frequency + 1,
            last_seen: new Date().toISOString(),
            risk_outcome: riskOutcome
          })
          .eq("id", memory.id);
        foundMatch = true;
        break;
      }
    }
  }
  
  // Insert new pattern if no match found
  if (!foundMatch) {
    await supabase
      .from("personal_threat_memory")
      .insert({
        user_id: userId,
        normalized_pattern: normalizedPattern,
        risk_outcome: riskOutcome,
        frequency: 1
      });
  }
}

function buildAdvancedPrompt(
  text: string | undefined,
  files: string[] | undefined,
  checklist: Record<string, boolean> | undefined,
  context: {
    corporatePatterns: CorporatePattern[];
    stealthSignatures: StealthSignature[];
    explanations: ExplanationEntry[];
    relevantExamples: any[];
  },
  userMemory: ThreatMemory[]
) {
  const parts: string[] = [];
  
  // Core identity and mission
  parts.push("SAFEWISE AI — ENTERPRISE SECURITY BRAIN");
  parts.push("You are an advanced digital risk detection engine.");
  parts.push("Your mission: Protect users from sophisticated digital threats while avoiding false alarms.");
  
  // Intelligence context from database
  if (context.corporatePatterns.length > 0) {
    parts.push("\n=== LEGITIMATE CORPORATE BASELINE ===");
    parts.push("Use these patterns to identify normal corporate communication:");
    for (const pat of context.corporatePatterns) {
      parts.push(`• Industry: ${pat.industry} | Tone: ${pat.tone} | Baseline Risk: ${pat.risk_baseline}%`);
      parts.push(`  Phrases: ${pat.common_phrases}`);
    }
  }
  
  if (context.stealthSignatures.length > 0) {
    parts.push("\n=== STEALTH ATTACK SIGNATURES ===");
    parts.push("Detect these sophisticated attack patterns:");
    for (const sig of context.stealthSignatures) {
      parts.push(`• Type: ${sig.attack_type} | Weight: ${sig.risk_weight}%`);
      parts.push(`  Markers: ${sig.linguistic_markers}`);
      parts.push(`  Psychology: ${sig.psychological_pattern}`);
    }
  }
  
  if (context.relevantExamples.length > 0) {
    parts.push("\n=== REFERENCE EXAMPLES ===");
    parts.push("Similar messages from training dataset:");
    for (const ex of context.relevantExamples.slice(0, 5)) {
      parts.push(`• [${ex.risk_level.toUpperCase()}] Score: ${ex.risk_score} | Category: ${ex.category}`);
      parts.push(`  "${ex.message_text.slice(0, 100)}..."`);
    }
  }
  
  if (userMemory.length > 0) {
    parts.push("\n=== USER CONTEXT MEMORY ===");
    parts.push("Patterns previously seen by this user:");
    for (const mem of userMemory) {
      parts.push(`• Pattern (seen ${mem.frequency}x): ${mem.risk_outcome}`);
    }
  }
  
  // Analysis framework
  parts.push("\n=== ANALYSIS FRAMEWORK ===");
  parts.push("Evaluate using these layers:");
  parts.push("1. INTENT: Is the message trying to influence user action?");
  parts.push("2. AUTHENTICITY: Does it match real corporate communication patterns?");
  parts.push("3. TECHNICAL ACCURACY: Are technical terms used correctly?");
  parts.push("4. CONTEXT ROLE MATCH: Does the claimed department fit the content?");
  parts.push("5. DECEPTION INDICATORS: Ambiguity, passive voice, indirect urgency");
  parts.push("6. HARM POTENTIAL: Could this lead to fraud, identity theft, or data exposure?");
  
  // Calibration rules
  parts.push("\n=== CALIBRATION RULES ===");
  parts.push("• Role Mismatch: HR speaking like IT → +20% risk");
  parts.push("• IT speaking about finance → +25% risk");
  parts.push("• Explicit action requests → +40% risk");
  parts.push("• Indirect action requests → +20% risk");
  parts.push("• Suspicious technical jargon (alignment, token, propagation, cluster) → +15% per group");
  parts.push("• Purposeful ambiguity (no context, passive voice, future verifications) → +35% risk");
  parts.push("• Absence of links does NOT reduce risk");
  parts.push("• Inconsistent tone for department → +25% risk");
  parts.push("• MINIMUM score: 5 | MAXIMUM score: 99");
  
  // Risk levels
  parts.push("\n=== RISK CLASSIFICATION ===");
  parts.push("• LOW (5-25): Routine HR, scheduling, meeting reminders, payroll updates");
  parts.push("• MEDIUM (26-60): Ambiguous requests, vague notifications, unverifiable sources");
  parts.push("• STEALTH (61-85): Corporate mimicry, identity/access terminology, no-link attacks, impersonation");
  parts.push("• HIGH (86-99): Urgent threats, credential requests, time-limited demands");
  
  // Output format
  parts.push("\n=== OUTPUT FORMAT ===");
  parts.push("Return ONLY valid JSON:");
  parts.push(JSON.stringify({
    score: "integer 5-99",
    risk_level: "low|medium|stealth|high",
    category: "phishing|stealth-phishing|romance|identity|financial|legitimate|other",
    reasons: ["up to 6 clear reasons explaining WHY"],
    explanation: "clear, non-alarmist explanation for the user",
    recommended_actions: [{ type: "block|ignore|verify|report", label: "action label", payload: {} }],
    confidence: "high|medium|low"
  }, null, 2));
  
  // Content to analyze
  if (checklist) {
    parts.push("\n=== USER CHECKLIST ===");
    parts.push(JSON.stringify(checklist));
  }
  
  if (text) {
    parts.push("\n=== CONTENT TO ANALYZE ===");
    parts.push(text);
  }
  
  if (files && files.length > 0) {
    parts.push("\n=== ATTACHED FILES ===");
    files.forEach((u, i) => parts.push(`File[${i}]: ${u}`));
    parts.push("Extract and analyze any visible text from images.");
  }
  
  // Final instructions
  parts.push("\n=== CRITICAL INSTRUCTIONS ===");
  parts.push("• Prioritize user safety without causing alarm fatigue");
  parts.push("• Explain decisions clearly for non-technical users");
  parts.push("• Detect stealth attacks that bypass traditional filters");
  parts.push("• AVOID false positives on legitimate corporate communication");
  parts.push("• Be concise but thorough. Return only JSON.");
  
  return parts.join("\n");
}

// Get appropriate explanation from library
function getExplanationFromLibrary(
  riskLevel: string,
  category: string,
  explanations: ExplanationEntry[]
): { explanation: string; action: string } | null {
  // Try exact match first
  for (const exp of explanations) {
    if (exp.risk_level === riskLevel && exp.category === category) {
      return { explanation: exp.explanation_text, action: exp.recommended_action };
    }
  }
  
  // Fall back to risk level match
  for (const exp of explanations) {
    if (exp.risk_level === riskLevel) {
      return { explanation: exp.explanation_text, action: exp.recommended_action };
    }
  }
  
  return null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method Not Allowed" }), { 
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const body = (await req.json()) as AnalyzeRequest;
    if (!body?.userId) {
      return new Response(JSON.stringify({ error: "userId required" }), { 
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const contentToAnalyze = body.text || "";
    console.log("Analyzing content for user:", body.userId, "| OCR:", body.isOcrExtracted || false);

    // Fetch intelligence context and user memory in parallel
    const [intelligenceContext, userMemory] = await Promise.all([
      fetchIntelligenceContext(contentToAnalyze),
      fetchUserThreatMemory(body.userId, contentToAnalyze)
    ]);

    console.log("Intelligence context loaded:", {
      corporatePatterns: intelligenceContext.corporatePatterns.length,
      stealthSignatures: intelligenceContext.stealthSignatures.length,
      relevantExamples: intelligenceContext.relevantExamples.length,
      userMemory: userMemory.length
    });

    // Build enhanced prompt with intelligence context
    const prompt = buildAdvancedPrompt(
      body.text,
      body.files,
      body.checklist,
      intelligenceContext,
      userMemory
    );

    // Call Lovable AI Gateway
    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.05,
        max_tokens: 1000
      })
    });

    if (!aiRes.ok) {
      const errorText = await aiRes.text();
      console.error("AI Gateway error:", aiRes.status, errorText);
      
      if (aiRes.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), { 
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      if (aiRes.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required. Please add credits to your workspace." }), { 
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      return new Response(JSON.stringify({ error: "AI Gateway error", detail: errorText }), { 
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const aiJson = await aiRes.json();
    const rawContent = aiJson?.choices?.[0]?.message?.content ?? null;
    console.log("AI response received:", rawContent?.slice(0, 300));

    // Parse JSON from response
    let parsed: any = null;
    try {
      const jsonMatch = rawContent.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
      parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch (e) {
      console.error("Failed to parse AI response:", e);
      parsed = null;
    }

    // Fallback if parsing failed
    if (!parsed) {
      parsed = {
        score: 50,
        risk_level: "medium",
        category: "other",
        reasons: ["Could not extract structured output reliably"],
        explanation: "Analysis completed but results are uncertain. Please verify manually.",
        recommended_actions: [{ type: "verify", label: "Verify manually", payload: {} }],
        confidence: "low"
      };
    }

    // Ensure risk_level is set
    if (!parsed.risk_level) {
      const score = Number(parsed.score || 50);
      if (score <= 25) parsed.risk_level = "low";
      else if (score <= 60) parsed.risk_level = "medium";
      else if (score <= 85) parsed.risk_level = "stealth";
      else parsed.risk_level = "high";
    }

    // Enhance explanation from library if available
    const libraryExplanation = getExplanationFromLibrary(
      parsed.risk_level,
      parsed.category,
      intelligenceContext.explanations
    );
    
    if (libraryExplanation && !parsed.explanation) {
      parsed.explanation = libraryExplanation.explanation;
    }

    // Update user's threat memory
    await updateUserThreatMemory(
      body.userId,
      contentToAnalyze,
      parsed.risk_level,
      parsed.category
    );

    // Save analysis to DB
    const insertPayload = {
      user_id: body.userId,
      score: Number(parsed.score || 50),
      category: parsed.category || "other",
      reasons: parsed.reasons || [],
      recommended_actions: parsed.recommended_actions || [],
      original_text: body.text || null,
      file_urls: body.files || null,
      context: {
        checklist: body.checklist || null,
        raw_ai: rawContent,
        risk_level: parsed.risk_level,
        explanation: parsed.explanation,
        confidence: parsed.confidence,
        is_ocr_extracted: body.isOcrExtracted || false,
        intelligence_context: {
          matched_stealth_signatures: intelligenceContext.stealthSignatures.length,
          matched_corporate_patterns: intelligenceContext.corporatePatterns.length,
          user_memory_matches: userMemory.length
        }
      }
    };

    const { data: analysis, error: insertErr } = await supabase
      .from("analyses")
      .insert(insertPayload)
      .select()
      .single();

    if (insertErr) {
      console.error("Database insert error:", insertErr);
      return new Response(JSON.stringify({ error: "Failed to save analysis" }), { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    // Log usage
    await supabase.from("usage_logs").insert({
      user_id: body.userId,
      event: "analysis_requested",
      tokens_used: null,
      meta: {
        model: AI_MODEL,
        raw_ai_output: rawContent?.slice?.(0, 2000) ?? null,
        is_ocr: body.isOcrExtracted || false
      }
    });

    console.log("Analysis saved successfully:", analysis.id);

    // Ensure arrays are always present for frontend
    const safeResult = {
      score: Number(parsed.score || 50),
      risk_level: parsed.risk_level || "medium",
      category: parsed.category || "other",
      reasons: Array.isArray(parsed.reasons) ? parsed.reasons : [],
      recommended_actions: Array.isArray(parsed.recommended_actions) ? parsed.recommended_actions : [],
      explanation: parsed.explanation || "",
      confidence: parsed.confidence || "low"
    };

    return new Response(JSON.stringify({
      ok: true,
      result: safeResult,
      analysisId: analysis.id
    }), { 
      headers: { ...corsHeaders, "Content-Type": "application/json" } 
    });
  } catch (err) {
    console.error("Error in analyze-content:", err);
    return new Response(JSON.stringify({ error: String(err) }), { 
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});
