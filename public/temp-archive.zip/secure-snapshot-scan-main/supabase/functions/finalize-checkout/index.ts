import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  console.log(`[FINALIZE-CHECKOUT] ${step}`, details ? JSON.stringify(details) : "");
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY missing");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false } }
    );

    // Get authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header");

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !userData.user?.email) {
      throw new Error("User not authenticated");
    }

    const user = userData.user;
    logStep("User authenticated", { userId: user.id, email: user.email });

    // Find customer in Stripe by email
    const customers = await stripe.customers.list({
      email: user.email,
      limit: 1,
    });

    if (customers.data.length === 0) {
      logStep("No Stripe customer found");
      return new Response(
        JSON.stringify({ success: false, subscribed: false, message: "No customer found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    const customerId = customers.data[0].id;
    logStep("Found Stripe customer", { customerId });

    // Check for active subscriptions in Stripe
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 1,
    });

    let activeSub = subscriptions.data[0];

    // Also check for trialing if no active
    if (!activeSub) {
      const trialingSubs = await stripe.subscriptions.list({
        customer: customerId,
        status: "trialing",
        limit: 1,
      });
      activeSub = trialingSubs.data[0];
    }

    if (!activeSub) {
      logStep("No active subscription found in Stripe");
      return new Response(
        JSON.stringify({ success: false, subscribed: false, message: "No active subscription" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    logStep("Active subscription found in Stripe", { 
      subscriptionId: activeSub.id, 
      status: activeSub.status 
    });

    const periodEnd = activeSub.current_period_end
      ? new Date(activeSub.current_period_end * 1000).toISOString()
      : null;

    // Upsert subscription in database (bypass any RLS with service role)
    // Plan must be one of: 'member', 'pro', 'trust' per database constraint
    const { error: upsertError } = await supabase.from("subscriptions").upsert(
      {
        user_id: user.id,
        stripe_customer_id: customerId,
        stripe_subscription_id: activeSub.id,
        plan: "pro",
        status: activeSub.status,
        current_period_end: periodEnd,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" }
    );

    if (upsertError) {
      logStep("Error upserting subscription", { error: upsertError.message });
      // Try insert instead
      const { error: insertError } = await supabase.from("subscriptions").insert({
        user_id: user.id,
        stripe_customer_id: customerId,
        stripe_subscription_id: activeSub.id,
        plan: "pro",
        status: activeSub.status,
        current_period_end: periodEnd,
      });

      if (insertError) {
        logStep("Error inserting subscription", { error: insertError.message });
        throw new Error(`Failed to save subscription: ${insertError.message}`);
      }
    }

    logStep("Subscription saved to database");

    // Upsert badge
    const { error: badgeError } = await supabase.from("user_badges").upsert(
      {
        user_id: user.id,
        badge: "shield",
        issued_at: new Date().toISOString(),
      },
      { onConflict: "user_id" }
    );

    if (badgeError) {
      logStep("Badge upsert error (non-critical)", { error: badgeError.message });
    }

    logStep("Finalization complete", { subscribed: true });

    return new Response(
      JSON.stringify({
        success: true,
        subscribed: true,
        status: activeSub.status,
        subscription_end: periodEnd,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    logStep("ERROR", { message: errorMessage });
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
