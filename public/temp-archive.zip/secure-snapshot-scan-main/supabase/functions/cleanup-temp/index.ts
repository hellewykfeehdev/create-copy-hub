import { serve } from "https://deno.land/std@0.205.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const STORAGE_BUCKET = "uploads";
const DEFAULT_AUTO_DELETE_DAYS = 30;

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Starting cleanup process...");

    // 1) Delete expired uploads_temp
    const { data: expired, error: e1 } = await supabase
      .from("uploads_temp")
      .select("*")
      .lt("expires_at", new Date().toISOString());

    if (!e1 && expired && expired.length) {
      console.log(`Found ${expired.length} expired uploads`);
      for (const row of expired) {
        try {
          if (row.file_url) {
            const url = new URL(row.file_url);
            const pathParts = url.pathname.split('/');
            const fileName = pathParts[pathParts.length - 1];
            const userId = pathParts[pathParts.length - 2];
            const filePath = `${userId}/${fileName}`;
            
            await supabase.storage.from(STORAGE_BUCKET).remove([filePath]);
            console.log(`Deleted file: ${filePath}`);
          }
          await supabase.from("uploads_temp").delete().eq("id", row.id);
        } catch (err) {
          console.error("Cleanup error for individual file:", err);
        }
      }
    }

    // 2) Delete old analyses based on user preferences
    const { data: profiles } = await supabase.from("profiles").select("id, auto_delete_days");
    
    if (profiles) {
      for (const profile of profiles) {
        const days = profile.auto_delete_days || DEFAULT_AUTO_DELETE_DAYS;
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - days);
        
        const { error: delErr } = await supabase
          .from("analyses")
          .delete()
          .eq("user_id", profile.id)
          .lt("created_at", cutoffDate.toISOString());
        
        if (delErr) {
          console.error(`Error deleting analyses for user ${profile.id}:`, delErr);
        }
      }
    }

    // 3) Prune old usage logs (older than 90 days)
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    
    await supabase
      .from("usage_logs")
      .delete()
      .lt("created_at", ninetyDaysAgo.toISOString());

    console.log("Cleanup completed successfully");

    return new Response(JSON.stringify({ ok: true }), { 
      headers: { ...corsHeaders, "Content-Type": "application/json" } 
    });
  } catch (err) {
    console.error("Error in cleanup-temp:", err);
    return new Response(JSON.stringify({ error: String(err) }), { 
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});
