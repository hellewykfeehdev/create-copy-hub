import { serve } from "https://deno.land/std@0.205.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const AI_MODEL = "google/gemini-2.5-flash";

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method Not Allowed" }), { 
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const { userId, analysisId } = await req.json();
    if (!userId || !analysisId) {
      return new Response(JSON.stringify({ error: "userId and analysisId required" }), { 
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    console.log("Generating share image for analysis:", analysisId);

    // Fetch analysis
    const { data: analysis, error: aErr } = await supabase
      .from("analyses")
      .select("*")
      .eq("id", analysisId)
      .single();

    if (aErr || !analysis) {
      console.error("Analysis not found:", aErr);
      return new Response(JSON.stringify({ error: "analysis not found" }), { 
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const title = `SAFEWISE • ${analysis.category.toUpperCase()} RISK ${analysis.score}`;
    const reasons = (analysis.reasons || []).slice(0, 3).map((r: string, i: number) => `${i + 1}. ${r}`).join("  |  ");
    const captionPrompt = `Create 3 short celebratory but credible Instagram captions for this saved analysis. analysis summary: ${analysis.category}, score ${analysis.score}, reasons: ${reasons}. Return JSON array of 3 captions maximum (max 120 chars each)`;

    // Call Lovable AI Gateway for captions
    const capRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [{ role: "user", content: captionPrompt }],
        temperature: 0.7,
        max_tokens: 200
      })
    });

    const capJson = await capRes.json();
    const capRaw = capJson?.choices?.[0]?.message?.content ?? '["I checked this with SAFEWISE"]';
    let captions = [];
    try {
      captions = JSON.parse(capRaw);
    } catch (e) {
      captions = [capRaw.slice(0, 120)];
    }

    // Generate simple SVG
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920">
      <rect width="100%" height="100%" fill="#0F172A"/>
      <text x="54" y="160" fill="#FFFFFF" font-size="48" font-family="Inter, Arial, sans-serif">SAFEWISE</text>
      <text x="54" y="260" fill="#E11D48" font-size="40" font-family="Inter">${analysis.category.toUpperCase()} RISK ${analysis.score}</text>
      <foreignObject x="54" y="320" width="972" height="1000">
        <div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Inter, Arial, sans-serif; color:#fff; font-size:28px;">
          ${reasons}
        </div>
      </foreignObject>
      <text x="54" y="1840" fill="#9CA3AF" font-size="22">#SafeWise</text>
    </svg>`;

    const svgBase64 = "data:image/svg+xml;base64," + btoa(svg);

    await supabase.from("usage_logs").insert([
      { user_id: userId, event: "generate_share_image", meta: { analysisId } }
    ]);

    console.log("Share image generated successfully");

    return new Response(JSON.stringify({ ok: true, svg: svgBase64, captions }), { 
      headers: { ...corsHeaders, "Content-Type": "application/json" } 
    });
  } catch (err) {
    console.error("Error in generate-share-image:", err);
    return new Response(JSON.stringify({ error: String(err) }), { 
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});
