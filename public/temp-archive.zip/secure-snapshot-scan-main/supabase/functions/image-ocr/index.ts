import { serve } from "https://deno.land/std@0.205.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const AI_MODEL = "google/gemini-2.5-flash";

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type OcrRequest = {
  userId: string;
  imageUrl?: string;
  imageBase64?: string;
  analyzeAfterExtraction?: boolean;
};

const OCR_PROMPT = `You are a precise OCR (Optical Character Recognition) engine.

TASK: Extract ALL visible text from this image exactly as written.

RULES:
1. Preserve exact formatting, including:
   - Line breaks
   - Headers and subject lines
   - Sender names and email addresses
   - Timestamps and dates
   - Any visible signatures

2. Extract text in reading order (top to bottom, left to right)

3. Include ALL text elements:
   - Main body text
   - Headers/footers
   - Buttons/links (text only)
   - Watermarks if visible
   - Any metadata shown

4. Do NOT interpret or analyze the content
5. Do NOT add any commentary
6. Do NOT translate (keep original language)

OUTPUT FORMAT:
Return a JSON object:
{
  "extracted_text": "the complete extracted text here",
  "confidence": "high|medium|low",
  "text_elements": {
    "subject": "if email subject is visible",
    "sender": "if sender is visible", 
    "date": "if date/time is visible",
    "body": "main body text"
  }
}

If no text is visible, return:
{
  "extracted_text": "",
  "confidence": "low",
  "text_elements": {}
}`;

serve(async (req) => {
  console.log("📸 Image OCR requested by user:", req.method);
  
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method Not Allowed" }), { 
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const body = (await req.json()) as OcrRequest;
    console.log("📸 Image OCR requested by user:", body.userId);
    
    if (!body?.userId) {
      return new Response(JSON.stringify({ error: "userId required" }), { 
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    if (!body.imageUrl && !body.imageBase64) {
      return new Response(JSON.stringify({ error: "imageUrl or imageBase64 required" }), { 
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    console.log("🔍 Processing OCR via AI Gateway...");

    // Build message content with image
    const messageContent: any[] = [
      { type: "text", text: OCR_PROMPT }
    ];

    if (body.imageBase64) {
      // Base64 image
      messageContent.push({
        type: "image_url",
        image_url: {
          url: body.imageBase64.startsWith("data:") 
            ? body.imageBase64 
            : `data:image/png;base64,${body.imageBase64}`
        }
      });
    } else if (body.imageUrl) {
      // URL image
      messageContent.push({
        type: "image_url",
        image_url: { url: body.imageUrl }
      });
    }

    // Call Lovable AI Gateway with vision
    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [{
          role: "user",
          content: messageContent
        }],
        temperature: 0.1,
        max_tokens: 2000
      })
    });

    if (!aiRes.ok) {
      const errorText = await aiRes.text();
      console.error("AI Gateway error:", aiRes.status, errorText);
      
      if (aiRes.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), { 
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      if (aiRes.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required. Please add credits to your workspace." }), { 
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
      
      return new Response(JSON.stringify({ error: "AI Gateway error", detail: errorText }), { 
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    const aiJson = await aiRes.json();
    const rawContent = aiJson?.choices?.[0]?.message?.content ?? "";
    console.log("OCR response received:", rawContent.slice(0, 300));

    // Parse JSON from response
    let ocrResult: any = null;
    try {
      const jsonMatch = rawContent.match(/\{[\s\S]*\}/);
      ocrResult = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch (e) {
      console.error("Failed to parse OCR response:", e);
      // Try to extract text directly if JSON parsing fails
      ocrResult = {
        extracted_text: rawContent.replace(/```[\s\S]*?```/g, '').trim(),
        confidence: "low",
        text_elements: {}
      };
    }

    if (!ocrResult || !ocrResult.extracted_text) {
      ocrResult = {
        extracted_text: "",
        confidence: "low",
        text_elements: {}
      };
    }

    // Calculate confidence score (0-100)
    const confidenceScore = ocrResult.confidence === "high" ? 90 
      : ocrResult.confidence === "medium" ? 70 
      : 40;

    // Log OCR extraction for audit
    const { error: logError } = await supabase
      .from("image_text_extraction_log")
      .insert({
        user_id: body.userId,
        extracted_text: ocrResult.extracted_text,
        confidence_score: confidenceScore
      });

    if (logError) {
      console.error("Failed to log OCR extraction:", logError);
    }

    // Log usage
    await supabase.from("usage_logs").insert({
      user_id: body.userId,
      event: "ocr_extraction",
      tokens_used: null,
      meta: {
        model: AI_MODEL,
        confidence: ocrResult.confidence,
        text_length: ocrResult.extracted_text.length
      }
    });

    console.log("OCR extraction complete. Text length:", ocrResult.extracted_text.length);

    // If requested, forward to analyze-content
    if (body.analyzeAfterExtraction && ocrResult.extracted_text) {
      console.log("Forwarding extracted text to analyze-content...");
      
      const analyzeRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${SUPABASE_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: body.userId,
          text: ocrResult.extracted_text,
          isOcrExtracted: true
        })
      });

      if (analyzeRes.ok) {
        const analysisResult = await analyzeRes.json();
        console.log("Analysis complete after OCR");
        
        return new Response(JSON.stringify({
          ok: true,
          ocr: {
            extracted_text: ocrResult.extracted_text,
            confidence: ocrResult.confidence,
            text_elements: ocrResult.text_elements
          },
          analysis: analysisResult
        }), { 
          headers: { ...corsHeaders, "Content-Type": "application/json" } 
        });
      } else {
        console.error("Analysis failed after OCR:", await analyzeRes.text());
      }
    }

    return new Response(JSON.stringify({
      ok: true,
      ocr: {
        extracted_text: ocrResult.extracted_text,
        confidence: ocrResult.confidence,
        text_elements: ocrResult.text_elements
      }
    }), { 
      headers: { ...corsHeaders, "Content-Type": "application/json" } 
    });

  } catch (err) {
    console.error("Error in image-ocr:", err);
    return new Response(JSON.stringify({ error: String(err) }), { 
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
});
