import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const FULL_ACCESS_FEATURES = {
  unlimited_scans: true,
  history_access: true,
  share_images: true,
  priority_support: true,
  api_access: true,
  team_sharing: true,
};

const NO_ACCESS_FEATURES = {
  unlimited_scans: false,
  history_access: false,
  share_images: false,
  priority_support: false,
  api_access: false,
  team_sharing: false,
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  console.log(`[CHECK-SUBSCRIPTION] ${step}`, details ? JSON.stringify(details) : "");
};

function jsonResponse(data: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(data), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
    status,
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false } }
    );

    // Get user from auth header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      logStep("No auth header");
      return jsonResponse({ subscribed: false, features: NO_ACCESS_FEATURES });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabase.auth.getUser(token);

    if (userError || !userData.user?.id) {
      logStep("User auth failed", { error: userError?.message });
      return jsonResponse({ subscribed: false, features: NO_ACCESS_FEATURES });
    }

    const user = userData.user;
    logStep("User authenticated", { userId: user.id });

    // First, check database for subscription
    const { data: subscription } = await supabase
      .from("subscriptions")
      .select("status, current_period_end, stripe_subscription_id")
      .eq("user_id", user.id)
      .maybeSingle();

    logStep("Database subscription check", { subscription });

    const isActiveInDb =
      subscription &&
      (subscription.status === "active" || subscription.status === "trialing");

    if (isActiveInDb) {
      logStep("Active subscription found in DB");
      return jsonResponse({
        subscribed: true,
        status: subscription.status,
        access_level: "full",
        subscription_end: subscription.current_period_end ?? null,
        features: FULL_ACCESS_FEATURES,
      });
    }

    // If not in DB or not active, check Stripe directly as fallback
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey || !user.email) {
      logStep("Cannot check Stripe - missing key or email");
      return jsonResponse({ subscribed: false, features: NO_ACCESS_FEATURES });
    }

    logStep("Checking Stripe directly", { email: user.email });

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    // Find customer by email
    const customers = await stripe.customers.list({
      email: user.email,
      limit: 1,
    });

    if (customers.data.length === 0) {
      logStep("No Stripe customer found");
      return jsonResponse({ subscribed: false, features: NO_ACCESS_FEATURES });
    }

    const customerId = customers.data[0].id;
    logStep("Found Stripe customer", { customerId });

    // Check active subscriptions
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 1,
    });

    let activeSub = subscriptions.data[0];

    // Also check trialing if no active
    if (!activeSub) {
      const trialingSubs = await stripe.subscriptions.list({
        customer: customerId,
        status: "trialing",
        limit: 1,
      });
      activeSub = trialingSubs.data[0];
    }

    if (!activeSub) {
      logStep("No active subscription in Stripe");
      return jsonResponse({ subscribed: false, features: NO_ACCESS_FEATURES });
    }

    logStep("Active subscription found in Stripe", { subscriptionId: activeSub.id });

    const periodEnd = activeSub.current_period_end
      ? new Date(activeSub.current_period_end * 1000).toISOString()
      : null;

    // Sync to database for next time
    const { error: upsertError } = await supabase.from("subscriptions").upsert(
      {
        user_id: user.id,
        stripe_customer_id: customerId,
        stripe_subscription_id: activeSub.id,
        plan: "full",
        status: activeSub.status,
        current_period_end: periodEnd,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" }
    );

    if (upsertError) {
      logStep("DB sync error (non-critical)", { error: upsertError.message });
    } else {
      logStep("DB synced successfully");
    }

    return jsonResponse({
      subscribed: true,
      status: activeSub.status,
      access_level: "full",
      subscription_end: periodEnd,
      features: FULL_ACCESS_FEATURES,
    });
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    logStep("ERROR", { message: errorMessage });
    return jsonResponse({ subscribed: false, features: NO_ACCESS_FEATURES });
  }
});
