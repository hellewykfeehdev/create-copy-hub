-- Create security message dataset table
CREATE TABLE public.security_message_dataset (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_text TEXT NOT NULL,
  risk_level TEXT CHECK (risk_level IN ('low','medium','high','stealth')) NOT NULL,
  risk_score INT NOT NULL CHECK (risk_score >= 0 AND risk_score <= 100),
  category TEXT NOT NULL,
  rationale TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX dataset_risk_level_idx ON public.security_message_dataset (risk_level);
CREATE INDEX dataset_category_idx ON public.security_message_dataset (category);
CREATE INDEX dataset_risk_score_idx ON public.security_message_dataset (risk_score);

-- Enable RLS
ALTER TABLE public.security_message_dataset ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read
CREATE POLICY "allow authenticated read"
ON public.security_message_dataset
FOR SELECT
TO authenticated
USING (true);

-- Allow service role full access
CREATE POLICY "allow service role write"
ON public.security_message_dataset
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Insert LOW risk messages (30)
INSERT INTO public.security_message_dataset (message_text, risk_level, risk_score, category, rationale) VALUES
('Subject: Schedule Reminder. Hi, just confirming our meeting tomorrow at 3 PM.', 'low', 5, 'Corporate Routine', 'Standard communication without malicious intent'),
('Your payroll deposit will reflect on Friday as usual.', 'low', 5, 'HR', 'Routine, no suspicious instructions'),
('Here''s the weekly project update. No action needed.', 'low', 5, 'Work Update', 'Standard work communication'),
('Please review the attached training slides before Monday''s session.', 'low', 8, 'Training', 'Normal training request'),
('Your security badge has been renewed.', 'low', 5, 'Workplace', 'Routine security communication'),
('Facilities will perform AC maintenance on Thursday.', 'low', 5, 'Facilities', 'Standard facilities notice'),
('Your travel reimbursement has been approved.', 'low', 5, 'Finance', 'Normal approval notification'),
('I uploaded the new brand assets to the shared drive.', 'low', 5, 'Collaboration', 'Standard file sharing'),
('We updated the cafeteria menu for next week.', 'low', 5, 'General', 'Routine announcement'),
('Happy Holidays! Offices will be closed next Monday.', 'low', 5, 'General', 'Standard holiday notice'),
('The printer on Floor 2 has been serviced and is back online.', 'low', 5, 'IT Support', 'Normal IT notification'),
('Thanks for sending your report.', 'low', 5, 'Acknowledgment', 'Simple acknowledgment'),
('Just a reminder that parking spots will be reassigned next month.', 'low', 8, 'Facilities', 'Standard facility notice'),
('Can you send the invoice when possible? No rush.', 'low', 5, 'Finance', 'Normal request without urgency'),
('Welcome to the team! Your onboarding will start next week.', 'low', 5, 'HR', 'Standard onboarding'),
('Here is the meeting agenda for Thursday.', 'low', 5, 'Meeting', 'Normal meeting communication'),
('Let me know if you want support with the presentation.', 'low', 5, 'Collaboration', 'Helpful offer'),
('Tomorrow''s team lunch will happen at 12 PM.', 'low', 5, 'Social', 'Team event notice'),
('We updated the internal directory.', 'low', 5, 'General', 'Standard update notice'),
('Your wellness benefit credit has been added.', 'low', 5, 'Benefits', 'Normal benefits notification'),
('Your request for PTO has been accepted.', 'low', 5, 'HR', 'Standard PTO approval'),
('New office chairs will arrive this week.', 'low', 5, 'Facilities', 'Normal facility update'),
('Let me know if you need access to the shared room.', 'low', 5, 'Facilities', 'Standard access offer'),
('We''ve deployed UI fixes in the internal tool.', 'low', 5, 'IT', 'Normal IT update'),
('Attached is your proof of insurance.', 'low', 5, 'Benefits', 'Standard document delivery'),
('Please sign up for Friday''s training.', 'low', 8, 'Training', 'Normal training invitation'),
('The Q3 internal newsletter is ready.', 'low', 5, 'Communications', 'Standard newsletter'),
('We''re collecting feedback on team processes.', 'low', 5, 'HR', 'Normal feedback request'),
('Your equipment request is approved.', 'low', 5, 'IT', 'Standard approval'),
('Thanks for joining the webinar earlier today.', 'low', 5, 'Acknowledgment', 'Simple thank you');

-- Insert STEALTH risk messages (30)
INSERT INTO public.security_message_dataset (message_text, risk_level, risk_score, category, rationale) VALUES
('Your access configuration has been queued for alignment during the next identity cycle.', 'stealth', 65, 'Stealth Identity', 'Vague IT language, identity manipulation intent'),
('A verification checkpoint may appear on your next login.', 'stealth', 62, 'Authentication', 'Indirect authentication manipulation'),
('Your account has been flagged for routine compliance balancing.', 'stealth', 68, 'Compliance', 'Fake compliance language'),
('A sync was applied to your workspace. Please ensure your permissions look correct.', 'stealth', 70, 'Permissions', 'Indirect permission verification request'),
('Your identity token will refresh in the next maintenance cycle.', 'stealth', 66, 'Identity', 'Technical jargon for credential manipulation'),
('Some inconsistencies were found in user mapping. You may notice changes.', 'stealth', 72, 'Identity', 'Vague identity manipulation'),
('We included your account in the risk alignment batch.', 'stealth', 69, 'Security', 'Fabricated security process'),
('Unexpected user-role variance was detected.', 'stealth', 71, 'Role Management', 'Role manipulation attempt'),
('Your access logs require contextual confirmation.', 'stealth', 67, 'Access Control', 'Indirect verification request'),
('A silent authentication process has been scheduled.', 'stealth', 73, 'Authentication', 'Suspicious authentication language'),
('Your department''s profile schema was updated automatically.', 'stealth', 64, 'System Update', 'Vague system change notification'),
('Identity governance adjustments were performed.', 'stealth', 68, 'Identity', 'Fabricated governance process'),
('We identified anomalies in your workspace sync.', 'stealth', 70, 'Workspace', 'Fake anomaly detection'),
('A pending verification tag has been applied.', 'stealth', 66, 'Verification', 'Indirect verification manipulation'),
('Your role privileges are temporarily under review.', 'stealth', 74, 'Privileges', 'Role manipulation attempt'),
('A sensitive update occurred in your user cluster.', 'stealth', 69, 'System', 'Vague technical manipulation'),
('Some linked apps may require secondary verification soon.', 'stealth', 71, 'MFA', 'Indirect MFA manipulation'),
('An integrity check was triggered by new patterns in access logs.', 'stealth', 72, 'Security', 'Fabricated security check'),
('We''re rebalancing identity anchors across departments.', 'stealth', 67, 'Identity', 'Nonsensical technical jargon'),
('Operational sync flagged your profile for observation.', 'stealth', 70, 'Monitoring', 'Fake monitoring notification'),
('Role recalibration will propagate over the next cycle.', 'stealth', 68, 'Role Management', 'Vague role manipulation'),
('You may notice changes in workspace shortcuts due to policy adaptation.', 'stealth', 65, 'Policy', 'Indirect policy change'),
('Your multi-environment identifier needs harmonization.', 'stealth', 73, 'Identity', 'Fabricated identity process'),
('User normalization scripts affected your profile.', 'stealth', 69, 'System', 'Vague system manipulation'),
('Identity propagation has been delayed for your account.', 'stealth', 71, 'Identity', 'Fake identity process'),
('Cross-system correlation identified your account as outlier.', 'stealth', 74, 'Security', 'Fake anomaly detection'),
('Some items in your log record need contextual review.', 'stealth', 67, 'Audit', 'Indirect audit manipulation'),
('Your federated identity tag is pending alignment.', 'stealth', 70, 'Identity', 'Fabricated identity process'),
('A role conflict was detected in your session metadata.', 'stealth', 72, 'Session', 'Fake session issue'),
('Your user fingerprint requires silent confirmation.', 'stealth', 75, 'Authentication', 'Suspicious authentication request');

-- Insert HIGH risk messages (30)
INSERT INTO public.security_message_dataset (message_text, risk_level, risk_score, category, rationale) VALUES
('Your account is suspended. Verify immediately.', 'high', 92, 'Credential Theft', 'Urgent action, account suspension threat'),
('Unusual activity detected. Confirm your identity now.', 'high', 90, 'Identity Theft', 'Urgent identity verification'),
('You must validate your paycheck release today.', 'high', 88, 'Payroll Fraud', 'Urgent payroll manipulation'),
('We locked your account due to unauthorized access.', 'high', 94, 'Account Takeover', 'Account lock with urgency'),
('Failure to confirm your tax documents will result in penalties.', 'high', 89, 'Finance Attack', 'Threat-based urgency'),
('Your account will be disabled within 12 hours unless verified.', 'high', 93, 'Credential Theft', 'Time-limited threat'),
('Payment information mismatch. Update now.', 'high', 87, 'Finance Attack', 'Urgent payment manipulation'),
('Critical alert: credentials leaked. Reset required.', 'high', 95, 'Credential Compromise', 'Urgent credential reset'),
('Confirm your payroll information before 4 PM.', 'high', 88, 'Payroll Fraud', 'Time-limited payroll manipulation'),
('Compliance violation: review your access immediately.', 'high', 91, 'Compliance Attack', 'Urgent compliance threat'),
('Your account has been temporarily locked due to multiple failed login attempts. Restore access immediately.', 'high', 93, 'Credential Theft', 'Account lock with urgent action'),
('We could not verify your employment status. Confirm your identity to avoid payroll interruption.', 'high', 90, 'Payroll Fraud', 'Employment verification threat'),
('Your tax withholding details are incomplete. Finalize verification now.', 'high', 88, 'Finance Attack', 'Tax manipulation with urgency'),
('Security Alert: We detected unauthorized use of your internal ID.', 'high', 94, 'Security Threat', 'ID theft alert with urgency'),
('Your storage quota has exceeded limits and data may be removed if not confirmed.', 'high', 87, 'Data Manipulation', 'Data loss threat'),
('Your last authentication attempt failed. Reset your access to avoid suspension.', 'high', 91, 'Credential Reset Fraud', 'Authentication threat'),
('Your benefits coverage could not be confirmed. Revalidate your profile now.', 'high', 89, 'Benefits Fraud', 'Benefits manipulation'),
('Compliance issue detected: missing verification for restricted resources.', 'high', 92, 'Compliance Attack', 'Compliance threat'),
('We found discrepancies in your financial reimbursement submissions. Confirm your identity.', 'high', 90, 'Finance Attack', 'Financial fraud accusation'),
('A critical vulnerability was detected in your session. Restore secure mode immediately.', 'high', 95, 'Security Exploit', 'Security vulnerability threat'),
('Unauthorized document sharing was flagged under your user ID. Review your activity.', 'high', 91, 'Impersonation Threat', 'Activity accusation'),
('Your identity appears to be used from multiple locations.', 'high', 93, 'Account Takeover', 'Multi-location threat'),
('We could not authenticate your last expense claim. Validate immediately.', 'high', 88, 'Fraud Attempt', 'Expense fraud accusation'),
('Restricted access was granted from your account.', 'high', 94, 'Security Breach', 'Unauthorized access claim'),
('System detected mismatched multi-factor tokens.', 'high', 92, 'MFA Attack', 'MFA manipulation'),
('Your data export request is pending approval. Confirm if you initiated it.', 'high', 90, 'Data Exfiltration', 'Data export verification'),
('Sensitive internal documents were accessed under your profile.', 'high', 93, 'Insider Threat', 'Document access accusation'),
('High-risk unusual behavior detected on your account during compliance audit.', 'high', 91, 'Behavioral Attack', 'Behavioral accusation'),
('Your financial profile is incomplete and benefits processing may fail.', 'high', 89, 'Benefit Manipulation', 'Benefits threat'),
('Critical Action Required: access keys tied to your profile are compromised.', 'high', 96, 'Credential Compromise', 'Key compromise alert');

-- Insert GRAY/AMBIGUOUS risk messages (10)
INSERT INTO public.security_message_dataset (message_text, risk_level, risk_score, category, rationale) VALUES
('A pending authentication flag has been added. No action required yet.', 'medium', 45, 'Authentication', 'Ambiguous authentication notice'),
('Your benefits form will require confirmation soon.', 'medium', 35, 'Benefits', 'Future action hint'),
('A system flagged your department for review.', 'medium', 48, 'Review', 'Vague department review'),
('A new internal policy update may require your acknowledgement later this month.', 'medium', 32, 'Ambiguous Corporate', 'Future policy action'),
('Your department will undergo access restructuring soon.', 'medium', 50, 'Role Update', 'Future access change'),
('You might notice changes in your project permissions after the next sync.', 'medium', 42, 'System Update', 'Indirect permission change'),
('We identified minor inconsistencies in your profile metadata.', 'medium', 47, 'Metadata Review', 'Vague inconsistency claim'),
('Your attendance status will update once HR processes the backlog.', 'medium', 30, 'HR Ambiguous', 'Delayed update notice'),
('Your account is pending cross-system verification, but no action is required yet.', 'medium', 52, 'Identity Review', 'Pending verification notice'),
('Some of your workspace preferences will be reset during the upcoming cycle.', 'medium', 40, 'Workspace Change', 'Future preference reset');