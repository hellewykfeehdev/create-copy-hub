-- 1. corporate_pattern_library - Legitimate corporate communication patterns
CREATE TABLE public.corporate_pattern_library (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  industry text NOT NULL,
  region text NOT NULL,
  language_style text NOT NULL,
  common_phrases text NOT NULL,
  tone text NOT NULL,
  risk_baseline int NOT NULL DEFAULT 10 CHECK (risk_baseline >= 0 AND risk_baseline <= 100),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX corporate_pattern_industry_idx ON public.corporate_pattern_library (industry);
CREATE INDEX corporate_pattern_region_idx ON public.corporate_pattern_library (region);

ALTER TABLE public.corporate_pattern_library ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow authenticated read corporate patterns"
ON public.corporate_pattern_library
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "allow service role write corporate patterns"
ON public.corporate_pattern_library
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- 2. stealth_phishing_signatures - Silent/stealth attack patterns
CREATE TABLE public.stealth_phishing_signatures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attack_type text NOT NULL,
  linguistic_markers text NOT NULL,
  psychological_pattern text NOT NULL,
  common_phrases text NOT NULL,
  risk_weight int NOT NULL DEFAULT 50 CHECK (risk_weight >= 0 AND risk_weight <= 100),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX stealth_attack_type_idx ON public.stealth_phishing_signatures (attack_type);
CREATE INDEX stealth_risk_weight_idx ON public.stealth_phishing_signatures (risk_weight);

ALTER TABLE public.stealth_phishing_signatures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow authenticated read stealth signatures"
ON public.stealth_phishing_signatures
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "allow service role write stealth signatures"
ON public.stealth_phishing_signatures
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- 3. explainable_security_library - Reusable explanations
CREATE TABLE public.explainable_security_library (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high', 'stealth')),
  category text NOT NULL,
  explanation_text text NOT NULL,
  recommended_action text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX explainable_risk_level_idx ON public.explainable_security_library (risk_level);
CREATE INDEX explainable_category_idx ON public.explainable_security_library (category);

ALTER TABLE public.explainable_security_library ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow authenticated read explanations"
ON public.explainable_security_library
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "allow service role write explanations"
ON public.explainable_security_library
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- 4. personal_threat_memory - User-specific contextual memory
CREATE TABLE public.personal_threat_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  normalized_pattern text NOT NULL,
  risk_outcome text NOT NULL,
  frequency int NOT NULL DEFAULT 1,
  last_seen timestamptz DEFAULT now()
);

CREATE INDEX personal_threat_user_idx ON public.personal_threat_memory (user_id);
CREATE INDEX personal_threat_pattern_idx ON public.personal_threat_memory (normalized_pattern);

ALTER TABLE public.personal_threat_memory ENABLE ROW LEVEL SECURITY;

CREATE POLICY "personal_threat_memory_self_select"
ON public.personal_threat_memory
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "personal_threat_memory_self_insert"
ON public.personal_threat_memory
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "personal_threat_memory_self_update"
ON public.personal_threat_memory
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "allow service role write personal threat"
ON public.personal_threat_memory
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- 5. image_text_extraction_log - OCR extraction audit log
CREATE TABLE public.image_text_extraction_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  extracted_text text NOT NULL,
  confidence_score int NOT NULL DEFAULT 0 CHECK (confidence_score >= 0 AND confidence_score <= 100),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX image_extraction_user_idx ON public.image_text_extraction_log (user_id);
CREATE INDEX image_extraction_created_idx ON public.image_text_extraction_log (created_at);

ALTER TABLE public.image_text_extraction_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "image_extraction_self_select"
ON public.image_text_extraction_log
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "image_extraction_self_insert"
ON public.image_text_extraction_log
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "allow service role write image extraction"
ON public.image_text_extraction_log
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Insert initial stealth phishing signatures
INSERT INTO public.stealth_phishing_signatures (attack_type, linguistic_markers, psychological_pattern, common_phrases, risk_weight) VALUES
('identity_impersonation', 'vague authority claims, generic department names, no specific contact', 'trust exploitation, authority compliance', 'identity team, access management, security operations', 75),
('credential_harvesting', 'verification requests, authentication mentions, login prompts', 'urgency without deadline, implied consequences', 'verify your account, confirm identity, authentication required', 85),
('silent_reconnaissance', 'no action required yet, future action hints, observation language', 'normalization, trust building, preparation', 'flagged for review, pending verification, under observation', 65),
('corporate_mimicry', 'IT jargon overuse, policy references, compliance language', 'authority assumption, procedure exploitation', 'updated policy, access configuration, identity cycle', 70),
('psychological_priming', 'neutral first contact, relationship building, future promises', 'trust establishment, gradual escalation', 'no action needed now, more information coming, stay tuned', 55);

-- Insert initial corporate patterns (legitimate)
INSERT INTO public.corporate_pattern_library (industry, region, language_style, common_phrases, tone, risk_baseline) VALUES
('technology', 'global', 'casual professional', 'team sync, standup, sprint planning, code review', 'collaborative', 5),
('finance', 'global', 'formal', 'quarterly review, compliance audit, risk assessment', 'professional', 8),
('healthcare', 'global', 'empathetic professional', 'patient care, wellness program, benefits enrollment', 'supportive', 6),
('retail', 'global', 'friendly casual', 'shift schedule, inventory update, store meeting', 'approachable', 5),
('education', 'global', 'informative', 'curriculum update, student feedback, academic calendar', 'educational', 4);

-- Insert initial explanations library
INSERT INTO public.explainable_security_library (risk_level, category, explanation_text, recommended_action) VALUES
('low', 'legitimate_corporate', 'This message matches patterns of normal corporate communication. The tone, language, and context align with standard workplace exchanges.', 'No action needed. This appears to be a routine communication.'),
('low', 'personal_communication', 'This appears to be a personal or informal message without security indicators.', 'Safe to proceed. No suspicious elements detected.'),
('medium', 'ambiguous_request', 'This message contains some unusual elements but lacks clear threat indicators. The context requires careful evaluation.', 'Verify the sender through an alternative channel before taking any action.'),
('medium', 'unverified_source', 'The sender or source cannot be fully verified. Some elements deviate from expected patterns.', 'Do not click links or provide information. Contact your IT department if unsure.'),
('stealth', 'silent_phishing', 'This message uses sophisticated social engineering. It appears legitimate but contains hidden manipulation patterns designed to build trust before an attack.', 'Do not respond. Report to your security team. This may be a multi-stage attack.'),
('stealth', 'identity_probing', 'This message appears to be gathering information about your identity, access, or work patterns without making explicit requests.', 'Do not engage. Document and report. Monitor for follow-up messages.'),
('high', 'credential_theft', 'This message is attempting to steal your login credentials or personal information through deception.', 'Do not click any links. Do not enter any credentials. Report immediately to IT security.'),
('high', 'financial_fraud', 'This message is attempting financial fraud through impersonation or false urgency.', 'Stop all interaction. Verify through official channels. Report to security and finance teams.'),
('high', 'malware_delivery', 'This message likely contains or links to malicious software designed to compromise your device or network.', 'Do not open attachments. Do not click links. Disconnect from network if suspicious activity occurs.');