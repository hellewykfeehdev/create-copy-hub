-- Enable Row Level Security on stripe_customers table
ALTER TABLE public.stripe_customers ENABLE ROW LEVEL SECURITY;