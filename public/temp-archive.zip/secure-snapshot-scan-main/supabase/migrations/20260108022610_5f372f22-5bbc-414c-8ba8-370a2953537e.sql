-- Drop the sync_user_email trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_updated ON auth.users;

-- Drop the sync_user_email function
DROP FUNCTION IF EXISTS public.sync_user_email();

-- Remove the email column from profiles table (emails stay in auth.users only)
ALTER TABLE public.profiles DROP COLUMN IF EXISTS email;