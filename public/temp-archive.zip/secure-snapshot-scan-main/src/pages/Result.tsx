import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle2, 
  Copy, 
  Share2, 
  ChevronLeft,
  Ban,
  MessageSquare,
  Flag,
  ArrowRight
} from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { motion } from "framer-motion";

interface AnalysisResult {
  score: number;
  category: string;
  reasons: string[];
  recommended_actions: Array<{
    type: string;
    label: string;
    payload?: any;
  }>;
}

const Result = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [sharing, setSharing] = useState(false);
  
  const analysis = location.state?.analysis as AnalysisResult;
  const analysisId = location.state?.analysisId;

  if (!analysis) {
    navigate("/main");
    return null;
  }

  const getRiskLevel = (score: number) => {
    if (score >= 75) return { level: "HIGH", color: "destructive", bgClass: "bg-destructive/10", icon: AlertTriangle };
    if (score >= 40) return { level: "MEDIUM", color: "warning", bgClass: "bg-warning/10", icon: Shield };
    return { level: "LOW", color: "success", bgClass: "bg-success/10", icon: CheckCircle2 };
  };

  const risk = getRiskLevel(analysis.score);
  const RiskIcon = risk.icon;

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, any> = {
      phishing: Shield,
      romance: AlertTriangle,
      identity: Ban,
      financial: AlertTriangle,
      advertisement: Flag,
    };
    return icons[category] || Shield;
  };

  const CategoryIcon = getCategoryIcon(analysis.category);

  const handleCopyAction = (action: any) => {
    const message = action.payload?.message || `Action: ${action.label}`;
    navigator.clipboard.writeText(message);
    toast.success("Copied to clipboard!");
  };

  const handleShare = async () => {
    if (!analysisId) {
      toast.error("Cannot generate share image");
      return;
    }

    setSharing(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-share-image", {
        body: {
          userId: (await supabase.auth.getUser()).data.user?.id,
          analysisId,
        },
      });

      if (error) throw error;
      toast.success("Verification image ready!");
      console.log("Share data:", data);
    } catch (error: any) {
      toast.error(error.message || "Failed to generate image");
    } finally {
      setSharing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sentrix-header">
        <div className="container flex h-14 items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/main")}>
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <span className="font-medium">Analysis Result</span>
        </div>
      </header>

      <main className="container max-w-2xl mx-auto py-8 space-y-6">
        {/* Risk Score Hero */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Card className={`sentrix-card overflow-hidden ${risk.bgClass}`}>
            <CardContent className="pt-8 pb-8">
              <div className="text-center space-y-4">
                <div className={`mx-auto w-20 h-20 rounded-2xl flex items-center justify-center ${
                  risk.color === "destructive" ? "bg-destructive text-destructive-foreground" :
                  risk.color === "warning" ? "bg-warning text-warning-foreground" :
                  "bg-success text-success-foreground"
                }`}>
                  <RiskIcon className="w-10 h-10" />
                </div>
                <div>
                  <div className="text-5xl font-bold mb-3 text-foreground">{analysis.score}</div>
                  <Badge 
                    variant={risk.color as any} 
                    className="text-sm px-4 py-1"
                  >
                    {risk.level} RISK
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Category */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="sentrix-card">
            <CardContent className="py-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <CategoryIcon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Category</p>
                  <p className="font-medium text-foreground capitalize">{analysis.category}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Warning Signs */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="sentrix-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                Key Warning Signs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {(analysis.reasons || []).map((reason, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-md bg-destructive/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <span className="text-xs font-semibold text-destructive">{index + 1}</span>
                    </div>
                    <span className="text-sm text-foreground leading-relaxed">{reason}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recommended Actions */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="sentrix-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-success" />
                Recommended Actions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {(analysis.recommended_actions || []).map((action, index) => {
                const ActionIcon = action.type === 'block' ? Ban : 
                                 action.type === 'message' ? MessageSquare :
                                 action.type === 'report' ? Flag : Shield;
                
                return (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full justify-start h-auto py-3 px-4"
                    onClick={() => handleCopyAction(action)}
                  >
                    <ActionIcon className="h-4 w-4 mr-3 text-muted-foreground" />
                    <span className="flex-1 text-left text-sm">{action.label}</span>
                    <Copy className="h-4 w-4 text-muted-foreground" />
                  </Button>
                );
              })}
            </CardContent>
          </Card>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex gap-3"
        >
          <Button variant="outline" className="flex-1" onClick={handleShare} disabled={sharing}>
            <Share2 className="h-4 w-4 mr-2" />
            {sharing ? "Generating..." : "Share"}
          </Button>
          <Button className="flex-1 shadow-button hover:shadow-accent transition-all" onClick={() => navigate("/main")}>
            New Scan
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </motion.div>
      </main>
    </div>
  );
};

export default Result;
