import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Shield, Lock, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import AppHeader from "@/components/layout/AppHeader";
import { motion } from "framer-motion";

const Settings = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [autoDeleteDays, setAutoDeleteDays] = useState("30");
  const [fullName, setFullName] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/auth");
        return;
      }
      const { data, error } = await supabase
        .from("profiles")
        .select("auto_delete_days, display_name, full_name")
        .eq("id", user.id)
        .single();
      if (error) throw error;
      if (data) {
        setAutoDeleteDays(String(data.auto_delete_days || 30));
        setFullName(data.full_name || data.display_name || user.user_metadata?.full_name || "");
      }
    } catch (error: any) {
      console.error("Failed to load settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Update auth metadata
      await supabase.auth.updateUser({
        data: { full_name: fullName },
      });

      // Update profiles table
      const { error } = await supabase
        .from("profiles")
        .update({ 
          auto_delete_days: parseInt(autoDeleteDays),
          display_name: fullName,
          full_name: fullName
        })
        .eq("id", user.id);
      if (error) throw error;

      toast.success("Settings saved successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to save settings");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      
      <main className="container max-w-2xl mx-auto py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-foreground">Settings</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your account and preferences</p>
        </div>

        <div className="space-y-6">
          {/* Profile */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="sentrix-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium">Profile</CardTitle>
                <CardDescription className="text-sm">Your personal information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-sm font-medium">Full Name</Label>
                  <Input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="John Doe"
                    className="h-10"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Privacy */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="sentrix-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <Lock className="w-4 h-4 text-primary" />
                  Privacy Settings
                </CardTitle>
                <CardDescription className="text-sm">Control how your data is handled</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="auto-delete" className="text-sm font-medium">Auto-delete analyses after</Label>
                  <Select value={autoDeleteDays} onValueChange={setAutoDeleteDays}>
                    <SelectTrigger id="auto-delete" className="h-10">
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Analyses and uploaded files will be automatically deleted after this period
                  </p>
                </div>
                <div className="pt-2">
                  <Button onClick={handleSave} disabled={saving} className="shadow-button hover:shadow-accent transition-all">
                    {saving ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Settings"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Security Info */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="sentrix-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />
                  Data Security
                </CardTitle>
                <CardDescription className="text-sm">Your privacy and security commitments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <SecurityItem text="All uploads are encrypted in transit and at rest" />
                  <SecurityItem text="Your data is never shared with third parties" />
                  <SecurityItem text="Files are automatically deleted based on your preferences" />
                  <SecurityItem text="You can delete your account and all data at any time" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
    </div>
  );
};

const SecurityItem = ({ text }: { text: string }) => (
  <div className="flex items-center gap-2 text-sm text-muted-foreground">
    <CheckCircle className="w-4 h-4 text-success shrink-0" />
    <span>{text}</span>
  </div>
);

export default Settings;
