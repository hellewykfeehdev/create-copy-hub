import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Lock, 
  Eye, 
  CheckCircle, 
  AlertTriangle, 
  Fingerprint,
  Zap,
  ArrowRight,
  ShieldCheck,
  Brain
} from "lucide-react";
import { motion } from "framer-motion";
import { SentriXLogo } from "@/components/brand/SentriXLogo";
import { ThemeToggle } from "@/components/theme/ThemeToggle";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const Landing = () => {
  const navigate = useNavigate();
  const { session, loading } = useAuth();

  const handleGetStarted = () => {
    if (session) {
      navigate("/dashboard");
    } else {
      navigate("/auth");
    }
  };

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Header */}
      <header className="sentrix-header">
        <div className="container flex h-16 items-center justify-between">
          <SentriXLogo variant="icon" size="md" showText={true} />
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button 
              variant="ghost" 
              onClick={handleGetStarted}
              disabled={loading}
              className="font-medium"
            >
              {session ? "Dashboard" : "Sign In"}
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32">
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,hsl(var(--border)/0.5)_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border)/0.5)_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-40" />
        
        <motion.div 
          className="relative container max-w-4xl mx-auto text-center"
          initial="initial"
          animate="animate"
          variants={staggerContainer}
        >
          {/* Badge */}
          <motion.div variants={fadeInUp}>
            <Badge variant="outline" className="mb-8 px-4 py-1.5 text-sm font-medium border-border/60 bg-card/50 backdrop-blur-sm">
              <Zap className="w-3.5 h-3.5 mr-1.5 text-primary" />
              Enterprise-grade protection
            </Badge>
          </motion.div>

          {/* Main Headline */}
          <motion.h1 
            variants={fadeInUp}
            className="text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight text-foreground leading-[1.1] mb-6"
          >
            Silent Intelligence Against
            <br />
            <span className="text-primary">Digital Threats</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p 
            variants={fadeInUp}
            className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Detect what others can't. Advanced AI protection against phishing, 
            social engineering, and stealth manipulation tactics.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button 
              size="lg" 
              onClick={handleGetStarted}
              disabled={loading}
              className="h-12 px-8 text-base font-medium shadow-button hover:shadow-accent transition-all"
            >
              Get Protected
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <p className="text-sm text-muted-foreground">
              Start with a 14-day guarantee
            </p>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div 
            variants={fadeInUp}
            className="flex flex-wrap justify-center gap-8 text-sm text-muted-foreground"
          >
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" />
              <span>Privacy-first</span>
            </div>
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-primary" />
              <span>No inbox access</span>
            </div>
            <div className="flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-primary" />
              <span>Cryptographic verification</span>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Threat Types Section */}
      <section className="py-24 border-t border-border/50">
        <div className="container max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-2xl sm:text-3xl font-semibold text-foreground mb-4">
              What We Detect
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Advanced AI analysis identifies threats that traditional filters miss
            </p>
          </div>
          
          <div className="grid sm:grid-cols-3 gap-6">
            <ThreatCard
              icon={<AlertTriangle className="w-6 h-6" />}
              title="Stealth Phishing"
              description="Detect sophisticated phishing attacks, hidden malicious links, and credential harvesting attempts."
            />
            <ThreatCard
              icon={<Eye className="w-6 h-6" />}
              title="Impersonation"
              description="Identify when someone pretends to be a trusted contact, company, or authority figure."
            />
            <ThreatCard
              icon={<Brain className="w-6 h-6" />}
              title="Social Engineering"
              description="Recognize psychological manipulation, false urgency, and behavioral exploitation tactics."
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-muted/30 border-t border-border/50">
        <div className="container max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-2xl sm:text-3xl font-semibold text-foreground mb-4">
              Invisible Protection. Intelligent Defense.
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              The same security analysis used by enterprise teams, now available to everyone
            </p>
          </div>
          
          <div className="grid sm:grid-cols-3 gap-6">
            <FeatureCard
              icon={<ShieldCheck className="w-6 h-6" />}
              title="Instant Analysis"
              description="Paste any suspicious message and get detailed threat assessment in seconds."
            />
            <FeatureCard
              icon={<Fingerprint className="w-6 h-6" />}
              title="Verification Images"
              description="Generate cryptographically signed proof of analysis for legal or compliance needs."
            />
            <FeatureCard
              icon={<CheckCircle className="w-6 h-6" />}
              title="Threat History"
              description="Build your personal threat intelligence database with every analysis."
            />
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 border-t border-border/50">
        <div className="container max-w-xl mx-auto text-center">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-semibold text-foreground mb-4">
            Where Phishing Fails
          </h2>
          <p className="text-muted-foreground mb-8">
            Activate silent protection and stay ahead of digital threats.
          </p>
          <Button 
            size="lg"
            onClick={handleGetStarted}
            disabled={loading}
            className="h-12 px-8 text-base font-medium shadow-button hover:shadow-accent transition-all"
          >
            Activate Protection
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border/50">
        <div className="container">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <SentriXLogo variant="icon" size="sm" showText={true} />
            <p>Silent Intelligence Against Digital Threats</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

const ThreatCard = ({ 
  icon, 
  title, 
  description 
}: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
}) => (
  <div className="sentrix-card p-6 text-center">
    <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-destructive/10 flex items-center justify-center text-destructive">
      {icon}
    </div>
    <h3 className="font-semibold mb-2 text-foreground">{title}</h3>
    <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
  </div>
);

const FeatureCard = ({ 
  icon, 
  title, 
  description 
}: { 
  icon: React.ReactNode; 
  title: string; 
  description: string;
}) => (
  <div className="sentrix-card p-6 text-center">
    <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
      {icon}
    </div>
    <h3 className="font-semibold mb-2 text-foreground">{title}</h3>
    <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
  </div>
);

export default Landing;
