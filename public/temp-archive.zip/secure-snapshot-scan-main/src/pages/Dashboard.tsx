import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  Loader2, 
  Shield, 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  History, 
  Settings, 
  Search, 
  Eye, 
  UserX, 
  Lock, 
  Brain, 
  TrendingUp, 
  ChevronRight, 
  CreditCard, 
  Check, 
  X,
  Zap,
  ArrowRight
} from "lucide-react";
import { toast } from "sonner";
import AppHeader from "@/components/layout/AppHeader";
import { motion } from "framer-motion";

// Feature item component
const FeatureItem = ({ enabled, label }: { enabled?: boolean; label: string }) => (
  <div className={`flex items-center gap-2 p-2.5 rounded-lg ${enabled ? 'bg-success/5 border border-success/20' : 'bg-muted/50'}`}>
    {enabled ? (
      <Check className="w-4 h-4 text-success shrink-0" />
    ) : (
      <X className="w-4 h-4 text-muted-foreground shrink-0" />
    )}
    <span className={`text-sm ${enabled ? 'text-foreground' : 'text-muted-foreground'}`}>
      {label}
    </span>
  </div>
);

interface Analysis {
  id: string;
  created_at: string;
  score: number | null;
  category: string | null;
  reasons: any;
  recommended_actions: any;
  original_text: string | null;
}

const Dashboard = () => {
  const { session, subscription, signOut, loading: authLoading } = useAuth();
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [preferences, setPreferences] = useState({
    autoScan: true,
    notifications: true,
  });
  const navigate = useNavigate();

  // Get user's display name
  const userName = session?.user?.user_metadata?.full_name;

  useEffect(() => {
    if (!authLoading && !session) {
      navigate("/auth");
    }
  }, [authLoading, session, navigate]);

  useEffect(() => {
    if (session?.user?.id && subscription?.subscribed) {
      const loadAnalyses = async () => {
        try {
          const { data, error } = await supabase
            .from("analyses")
            .select("*")
            .eq("user_id", session.user.id)
            .order("created_at", { ascending: false })
            .limit(5);
          if (error) throw error;
          setAnalyses(data || []);
        } catch (error) {
          console.error("Error loading analyses:", error);
        } finally {
          setLoading(false);
        }
      };
      loadAnalyses();
    } else {
      setLoading(false);
    }
  }, [session?.user?.id, subscription?.subscribed]);

  const handleManageSubscription = async () => {
    if (!session?.access_token) {
      toast.error("Please sign in first");
      return;
    }
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal", {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err: any) {
      console.error("Portal error:", err);
      toast.error("Failed to open subscription portal");
    }
  };

  const latestAnalysis = analyses[0];

  const getStatusInfo = (score: number | null) => {
    if (score === null) return { status: "No Data", color: "muted", icon: Shield };
    if (score <= 30) return { status: "Protected", color: "success", icon: ShieldCheck };
    if (score <= 60) return { status: "Attention Required", color: "warning", icon: AlertTriangle };
    return { status: "Risk Detected", color: "destructive", icon: ShieldAlert };
  };

  const getRiskBadge = (score: number | null) => {
    if (score === null) return { label: "N/A", variant: "outline" as const };
    if (score <= 30) return { label: "Low Risk", variant: "default" as const };
    if (score <= 60) return { label: "Medium Risk", variant: "secondary" as const };
    return { label: "High Risk", variant: "destructive" as const };
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Loading dashboard…</p>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(latestAnalysis?.score ?? null);
  const StatusIcon = statusInfo.icon;

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container max-w-5xl mx-auto py-8 space-y-6">
        {/* Welcome Message */}
        {userName && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-2"
          >
            <p className="text-sm text-muted-foreground">Welcome back,</p>
            <h1 className="text-2xl font-semibold text-foreground">{userName}</h1>
          </motion.div>
        )}

        {/* Subscription Status */}
        {subscription && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className={`sentrix-card border-l-4 ${
              subscription.status === "trialing" ? "border-l-primary" :
              subscription.status === "canceled" ? "border-l-warning" :
              "border-l-success"
            }`}>
              <CardContent className="flex flex-col sm:flex-row items-start sm:items-center justify-between py-4 gap-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    subscription.status === "trialing" ? "bg-primary/10" :
                    subscription.status === "canceled" ? "bg-warning/10" :
                    "bg-success/10"
                  }`}>
                    <ShieldCheck className={`w-5 h-5 ${
                      subscription.status === "trialing" ? "text-primary" :
                      subscription.status === "canceled" ? "text-warning" :
                      "text-success"
                    }`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-foreground">{subscription.level}</p>
                      {subscription.status === "trialing" && (
                        <Badge variant="secondary" className="text-xs">Trial</Badge>
                      )}
                      {subscription.status === "canceled" && (
                        <Badge variant="secondary" className="text-xs bg-warning/10 text-warning">Canceled</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {subscription.status === "trialing"
                        ? `Trial ends ${new Date(subscription.subscription_end!).toLocaleDateString()}`
                        : subscription.status === "canceled"
                        ? `Access until ${new Date(subscription.subscription_end!).toLocaleDateString()}`
                        : "Protection active"}
                    </p>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={handleManageSubscription}>
                  <CreditCard className="w-4 h-4 mr-2" />
                  Manage
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Safety Status Hero */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="sentrix-card overflow-hidden">
            <div className={`p-8 ${
              statusInfo.color === "success" ? "bg-gradient-to-br from-success/5 to-success/10" : 
              statusInfo.color === "warning" ? "bg-gradient-to-br from-warning/5 to-warning/10" : 
              statusInfo.color === "destructive" ? "bg-gradient-to-br from-destructive/5 to-destructive/10" : 
              "bg-muted/30"
            }`}>
              <div className="flex flex-col md:flex-row md:items-center gap-6">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                  statusInfo.color === "success" ? "bg-success text-success-foreground" : 
                  statusInfo.color === "warning" ? "bg-warning text-warning-foreground" : 
                  statusInfo.color === "destructive" ? "bg-destructive text-destructive-foreground" : 
                  "bg-muted text-muted-foreground"
                }`}>
                  <StatusIcon className="w-8 h-8" />
                </div>
                <div className="flex-1">
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">
                    Security Status
                  </p>
                  <h2 className="text-2xl font-semibold mb-1 text-foreground">{statusInfo.status}</h2>
                  <p className="text-sm text-muted-foreground">
                    {latestAnalysis
                      ? `Last scan: ${latestAnalysis.category || "General"} • ${formatDate(latestAnalysis.created_at)}`
                      : "No scans yet. Run your first analysis."}
                  </p>
                </div>
                <Button size="lg" onClick={() => navigate("/main")} className="shadow-button hover:shadow-accent transition-all">
                  <Search className="w-4 h-4 mr-2" />
                  New Scan
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Safety Index */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="sentrix-card">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base font-medium">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  Safety Index
                </CardTitle>
                <CardDescription className="text-sm">Your current trust score</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-6">
                  <div className={`w-20 h-20 rounded-2xl flex items-center justify-center font-bold text-2xl ${
                    (latestAnalysis?.score ?? 100) <= 30 ? "bg-success/10 text-success border-2 border-success/30" : 
                    (latestAnalysis?.score ?? 100) <= 60 ? "bg-warning/10 text-warning border-2 border-warning/30" : 
                    "bg-destructive/10 text-destructive border-2 border-destructive/30"
                  }`}>
                    {latestAnalysis?.score !== null && latestAnalysis?.score !== undefined ? 100 - latestAnalysis.score : "--"}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-2">
                      {latestAnalysis ? "Based on recent analysis" : "Complete a scan to see your score"}
                    </p>
                    {latestAnalysis && (
                      <Badge variant={getRiskBadge(latestAnalysis.score).variant}>
                        {getRiskBadge(latestAnalysis.score).label}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Preferences */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="sentrix-card">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base font-medium">
                  <Settings className="w-4 h-4 text-primary" />
                  Quick Settings
                </CardTitle>
                <CardDescription className="text-sm">Protection preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-scan" className="cursor-pointer text-sm">
                    Auto-scan clipboard
                  </Label>
                  <Switch
                    id="auto-scan"
                    checked={preferences.autoScan}
                    onCheckedChange={(checked) => setPreferences((p) => ({ ...p, autoScan: checked }))}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications" className="cursor-pointer text-sm">
                    Risk notifications
                  </Label>
                  <Switch
                    id="notifications"
                    checked={preferences.notifications}
                    onCheckedChange={(checked) => setPreferences((p) => ({ ...p, notifications: checked }))}
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Plan Features */}
        {subscription && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="sentrix-card">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base font-medium">
                  <Zap className="w-4 h-4 text-primary" />
                  Your Plan Features
                </CardTitle>
                <CardDescription className="text-sm">Unlocked with {subscription.level}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <FeatureItem enabled={subscription.features.history_access} label="Threat History" />
                  <FeatureItem enabled={subscription.features.unlimited_scans} label="Unlimited Scans" />
                  <FeatureItem enabled={subscription.features.share_images} label="Verification Images" />
                  <FeatureItem enabled={subscription.features.priority_support} label="Priority Support" />
                  <FeatureItem enabled={subscription.features.api_access} label="API Access" />
                  <FeatureItem enabled={subscription.features.team_sharing} label="Team Sharing" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Recent Analyses */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="sentrix-card">
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <div>
                <CardTitle className="flex items-center gap-2 text-base font-medium">
                  <History className="w-4 h-4 text-primary" />
                  Recent Scans
                </CardTitle>
                <CardDescription className="text-sm">Your latest security analyses</CardDescription>
              </div>
              <Button variant="ghost" size="sm" onClick={() => navigate("/history")}>
                View All <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : analyses.length === 0 ? (
                <div className="text-center py-10">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-xl bg-muted/50 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">No scans yet</p>
                  <Button onClick={() => navigate("/main")} variant="outline" size="sm">
                    Start First Scan
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  {analyses.map((analysis) => (
                    <div
                      key={analysis.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:bg-muted/30 transition-colors cursor-pointer"
                      onClick={() =>
                        navigate("/result", {
                          state: {
                            score: analysis.score,
                            category: analysis.category,
                            reasons: analysis.reasons,
                            recommendedActions: analysis.recommended_actions,
                            originalText: analysis.original_text,
                            analysisId: analysis.id,
                          },
                        })
                      }
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                          (analysis.score ?? 0) <= 30 ? "bg-success/10 text-success" :
                          (analysis.score ?? 0) <= 60 ? "bg-warning/10 text-warning" :
                          "bg-destructive/10 text-destructive"
                        }`}>
                          {(analysis.score ?? 0) <= 30 ? <ShieldCheck className="w-4 h-4" /> :
                           (analysis.score ?? 0) <= 60 ? <AlertTriangle className="w-4 h-4" /> :
                           <ShieldAlert className="w-4 h-4" />}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground capitalize">
                            {analysis.category || "General"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Score: {analysis.score ?? "N/A"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground hidden sm:block">
                          {formatDate(analysis.created_at)}
                        </span>
                        <ChevronRight className="w-4 h-4 text-muted-foreground" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
};

export default Dashboard;
