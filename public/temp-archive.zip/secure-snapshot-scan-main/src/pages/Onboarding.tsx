import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Target, CheckCircle2, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const Onboarding = () => {
  const [step, setStep] = useState(0);
  const navigate = useNavigate();

  const steps = [
    {
      icon: Shield,
      title: "Detect What Others Can't",
      description: "Paste suspicious messages, upload screenshots, or share links. Our AI analyzes threats in seconds.",
      items: ["Chat screenshots", "Email messages", "Suspicious links", "Advertisement images"]
    },
    {
      icon: Target,
      title: "Clear Risk Assessment",
      description: "Receive instant analysis with a clear score, category, and detailed threat indicators.",
      items: ["Risk Score (0-100)", "Threat category", "Key warning signs", "Immediate actions"]
    },
    {
      icon: CheckCircle2,
      title: "Take Action Immediately",
      description: "Follow recommended actions with ready-to-send messages and clear next steps.",
      items: ["Block sender", "Report threat", "Template replies", "Share with others"]
    }
  ];

  const currentStep = steps[step];
  const Icon = currentStep.icon;

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      navigate("/main");
    }
  };

  const handleSkip = () => {
    navigate("/main");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      {/* Background pattern */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,hsl(var(--border)/0.5)_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border)/0.5)_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30" />
      
      <div className="relative w-full max-w-md space-y-6">
        {/* Logo */}
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-3"
        >
          <div className="mx-auto w-16 h-16 rounded-xl bg-primary flex items-center justify-center shadow-lg">
            <Shield className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">SentriX</h1>
        </motion.div>

        <Card className="sentrix-card">
          <CardContent className="pt-8 pb-6 space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                {/* Step Icon */}
                <div className="flex justify-center">
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                </div>

                {/* Content */}
                <div className="text-center space-y-2">
                  <h2 className="text-xl font-semibold text-foreground">{currentStep.title}</h2>
                  <p className="text-sm text-muted-foreground leading-relaxed">{currentStep.description}</p>
                </div>

                {/* Items */}
                <div className="space-y-2">
                  {currentStep.items.map((item, index) => (
                    <div 
                      key={index} 
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border/50"
                    >
                      <div className="w-2 h-2 rounded-full bg-primary" />
                      <span className="text-sm text-foreground">{item}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Progress Dots */}
            <div className="flex items-center justify-center gap-2 pt-2">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    index === step ? 'w-6 bg-primary' : 'w-1.5 bg-muted-foreground/30'
                  }`}
                />
              ))}
            </div>

            {/* Buttons */}
            <div className="space-y-2 pt-2">
              <Button 
                onClick={handleNext} 
                className="w-full h-11 shadow-button hover:shadow-accent transition-all"
              >
                {step < steps.length - 1 ? (
                  <>
                    Next
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                ) : (
                  "Get Started"
                )}
              </Button>
              <Button onClick={handleSkip} variant="ghost" className="w-full">
                Skip
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Onboarding;
