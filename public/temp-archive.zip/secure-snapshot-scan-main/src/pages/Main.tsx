import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, ShieldOff, Lock, Search, ClipboardList } from "lucide-react";
import QuickChecklistTab from "@/components/main/QuickChecklistTab";
import AnalysisInputCard from "@/components/main/AnalysisInputCard";
import SavedShareImages from "@/components/main/SavedShareImages";
import PaywallModal from "@/components/subscription/PaywallModal";
import AppHeader from "@/components/layout/AppHeader";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const Main = () => {
  const {
    session,
    subscription,
    checkSubscription,
    loading: authLoading
  } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !session) {
      navigate("/auth");
    }
  }, [authLoading, session, navigate]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const checkoutStatus = params.get("checkout");
    if (checkoutStatus === "success") {
      checkSubscription();
      params.delete("checkout");
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, [checkSubscription]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const showPaywall = session && !subscription.subscribed;

  return (
    <div className="min-h-screen bg-background">
      {/* Paywall Modal */}
      <PaywallModal isOpen={showPaywall} />
      
      {/* Header */}
      <AppHeader disableNav={showPaywall} />
      
      {/* Main Content */}
      <main className={`container max-w-3xl mx-auto py-8 ${showPaywall ? "blur-sm pointer-events-none select-none" : ""}`}>
        {!subscription.subscribed ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="sentrix-card p-8 text-center"
          >
            <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-muted/50 flex items-center justify-center">
              <ShieldOff className="w-7 h-7 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Protection Inactive</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Activate your plan to unlock threat analysis
            </p>
            <Button disabled variant="outline">
              <Lock className="w-4 h-4 mr-2" />
              Analysis Locked
            </Button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Tabs defaultValue="analyze" className="space-y-6">
              <TabsList className="grid grid-cols-2 w-full max-w-sm mx-auto">
                <TabsTrigger value="analyze" className="gap-2">
                  <Search className="w-4 h-4" />
                  Analyze
                </TabsTrigger>
                <TabsTrigger value="checklist" className="gap-2">
                  <ClipboardList className="w-4 h-4" />
                  Checklist
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="analyze" className="space-y-6">
                <AnalysisInputCard userId={session.user.id} />
                <SavedShareImages userId={session.user.id} />
              </TabsContent>
              
              <TabsContent value="checklist">
                <QuickChecklistTab userId={session.user.id} />
              </TabsContent>
            </Tabs>
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default Main;
