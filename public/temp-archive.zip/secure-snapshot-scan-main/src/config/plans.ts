// SentriX Stripe pricing configuration - Single Plan with Monthly/Annual billing
// Product: SentriX Full (prod_TimY3dNKx8v5Wa)

export const FULL_PROTECTION_PRODUCT = {
  id: 'sentrix-full',
  productId: 'prod_Tl1VsFMs4WbMMU',
  name: 'SentriX Full',
  tagline: 'Silent protection against phishing and social engineering.',
  description: 'Complete protection against stealth phishing, social engineering, and behavioral manipulation. Enterprise-grade threat detection.',
  features: [
    'Unlimited threat scans',
    'Advanced stealth phishing detection',
    'Behavioral manipulation analysis',
    'Full threat history',
    'Cryptographic verification images',
    'Priority support',
    'Real-time threat alerts',
  ],
  pricing: {
    monthly: {
      priceId: 'price_1SnVSDHVT04ii1CNhL6T1fr3',
      price: 17,
      interval: 'month' as const,
      label: 'Monthly',
    },
    annual: {
      priceId: 'price_1SnVSDHVT04ii1CNprcZPo8g',
      price: 147,
      interval: 'year' as const,
      label: 'Annual',
      savings: 'Save 2 months',
    },
  },
} as const;

export type BillingInterval = 'monthly' | 'annual';
