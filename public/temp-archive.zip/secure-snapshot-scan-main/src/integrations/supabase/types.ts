export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      analyses: {
        Row: {
          category: string | null
          context: Json | null
          created_at: string | null
          file_urls: string[] | null
          id: string
          original_text: string | null
          reasons: Json | null
          recommended_actions: Json | null
          score: number | null
          user_id: string | null
        }
        Insert: {
          category?: string | null
          context?: Json | null
          created_at?: string | null
          file_urls?: string[] | null
          id?: string
          original_text?: string | null
          reasons?: Json | null
          recommended_actions?: Json | null
          score?: number | null
          user_id?: string | null
        }
        Update: {
          category?: string | null
          context?: Json | null
          created_at?: string | null
          file_urls?: string[] | null
          id?: string
          original_text?: string | null
          reasons?: Json | null
          recommended_actions?: Json | null
          score?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "analyses_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      analysis_share_images: {
        Row: {
          analysis_id: string
          created_at: string | null
          id: string
          image_hash: string
          image_url: string
          user_id: string
          watermark_payload: Json | null
        }
        Insert: {
          analysis_id: string
          created_at?: string | null
          id?: string
          image_hash: string
          image_url: string
          user_id: string
          watermark_payload?: Json | null
        }
        Update: {
          analysis_id?: string
          created_at?: string | null
          id?: string
          image_hash?: string
          image_url?: string
          user_id?: string
          watermark_payload?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "analysis_share_images_analysis_id_fkey"
            columns: ["analysis_id"]
            isOneToOne: true
            referencedRelation: "analyses"
            referencedColumns: ["id"]
          },
        ]
      }
      corporate_pattern_library: {
        Row: {
          body_pattern: string | null
          common_phrases: string | null
          created_at: string | null
          id: string
          industry: string
          language_style: string | null
          region: string
          risk_baseline: string
          subject_pattern: string | null
          tone: string | null
        }
        Insert: {
          body_pattern?: string | null
          common_phrases?: string | null
          created_at?: string | null
          id?: string
          industry: string
          language_style?: string | null
          region: string
          risk_baseline?: string
          subject_pattern?: string | null
          tone?: string | null
        }
        Update: {
          body_pattern?: string | null
          common_phrases?: string | null
          created_at?: string | null
          id?: string
          industry?: string
          language_style?: string | null
          region?: string
          risk_baseline?: string
          subject_pattern?: string | null
          tone?: string | null
        }
        Relationships: []
      }
      explainable_security_library: {
        Row: {
          category: string
          created_at: string | null
          explanation_text: string
          id: string
          recommended_action: string
          risk_level: string
        }
        Insert: {
          category: string
          created_at?: string | null
          explanation_text: string
          id?: string
          recommended_action: string
          risk_level: string
        }
        Update: {
          category?: string
          created_at?: string | null
          explanation_text?: string
          id?: string
          recommended_action?: string
          risk_level?: string
        }
        Relationships: []
      }
      image_text_extraction_log: {
        Row: {
          confidence_score: number
          created_at: string | null
          extracted_text: string
          id: string
          user_id: string | null
        }
        Insert: {
          confidence_score?: number
          created_at?: string | null
          extracted_text: string
          id?: string
          user_id?: string | null
        }
        Update: {
          confidence_score?: number
          created_at?: string | null
          extracted_text?: string
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      legitimacy_anchor_rules: {
        Row: {
          active: boolean | null
          anchor_name: string
          created_at: string | null
          description: string
          id: string
          negative_indicators: string | null
          positive_indicators: string
          priority: number | null
          risk_offset: number
        }
        Insert: {
          active?: boolean | null
          anchor_name: string
          created_at?: string | null
          description: string
          id?: string
          negative_indicators?: string | null
          positive_indicators: string
          priority?: number | null
          risk_offset: number
        }
        Update: {
          active?: boolean | null
          anchor_name?: string
          created_at?: string | null
          description?: string
          id?: string
          negative_indicators?: string | null
          positive_indicators?: string
          priority?: number | null
          risk_offset?: number
        }
        Relationships: []
      }
      personal_threat_memory: {
        Row: {
          frequency: number
          id: string
          last_seen: string | null
          normalized_pattern: string
          risk_outcome: string
          user_id: string
        }
        Insert: {
          frequency?: number
          id?: string
          last_seen?: string | null
          normalized_pattern: string
          risk_outcome: string
          user_id: string
        }
        Update: {
          frequency?: number
          id?: string
          last_seen?: string | null
          normalized_pattern?: string
          risk_outcome?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          auto_delete_days: number | null
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          full_name: string | null
          id: string
          locale: string | null
          plan: string | null
          updated_at: string | null
        }
        Insert: {
          auto_delete_days?: number | null
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          full_name?: string | null
          id: string
          locale?: string | null
          plan?: string | null
          updated_at?: string | null
        }
        Update: {
          auto_delete_days?: number | null
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          full_name?: string | null
          id?: string
          locale?: string | null
          plan?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      security_message_dataset: {
        Row: {
          category: string
          created_at: string | null
          id: string
          message_text: string
          rationale: string
          risk_level: string
          risk_score: number
        }
        Insert: {
          category: string
          created_at?: string | null
          id?: string
          message_text: string
          rationale: string
          risk_level: string
          risk_score: number
        }
        Update: {
          category?: string
          created_at?: string | null
          id?: string
          message_text?: string
          rationale?: string
          risk_level?: string
          risk_score?: number
        }
        Relationships: []
      }
      stealth_phishing_signatures: {
        Row: {
          attack_type: string
          common_phrases: string
          created_at: string | null
          id: string
          linguistic_markers: string
          psychological_pattern: string
          risk_weight: number
        }
        Insert: {
          attack_type: string
          common_phrases: string
          created_at?: string | null
          id?: string
          linguistic_markers: string
          psychological_pattern: string
          risk_weight?: number
        }
        Update: {
          attack_type?: string
          common_phrases?: string
          created_at?: string | null
          id?: string
          linguistic_markers?: string
          psychological_pattern?: string
          risk_weight?: number
        }
        Relationships: []
      }
      stripe_customers: {
        Row: {
          created_at: string | null
          email: string | null
          id: string
          stripe_customer_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          email?: string | null
          id?: string
          stripe_customer_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string | null
          id?: string
          stripe_customer_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string | null
          current_period_end: string | null
          id: string
          plan: string | null
          status: string | null
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          current_period_end?: string | null
          id?: string
          plan?: string | null
          status?: string | null
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          current_period_end?: string | null
          id?: string
          plan?: string | null
          status?: string | null
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      uploads_temp: {
        Row: {
          created_at: string | null
          expires_at: string | null
          file_url: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          file_url?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          file_url?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "uploads_temp_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      usage_logs: {
        Row: {
          created_at: string | null
          event: string | null
          id: string
          meta: Json | null
          tokens_used: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          event?: string | null
          id?: string
          meta?: Json | null
          tokens_used?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          event?: string | null
          id?: string
          meta?: Json | null
          tokens_used?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "usage_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_badges: {
        Row: {
          badge: string | null
          issued_at: string | null
          user_id: string
        }
        Insert: {
          badge?: string | null
          issued_at?: string | null
          user_id: string
        }
        Update: {
          badge?: string | null
          issued_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          created_at: string | null
          current_period_end: string | null
          id: string
          status: string | null
          stripe_price_id: string | null
          stripe_product_id: string | null
          stripe_subscription_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          current_period_end?: string | null
          id?: string
          status?: string | null
          stripe_price_id?: string | null
          stripe_product_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          current_period_end?: string | null
          id?: string
          status?: string | null
          stripe_price_id?: string | null
          stripe_product_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
