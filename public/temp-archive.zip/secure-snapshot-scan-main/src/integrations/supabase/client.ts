import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "https://lhzulkrtuuoxuursxnqy.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxoenVsa3J0dXVveHV1cnN4bnF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2OTQ2MzQsImV4cCI6MjA3OTI3MDYzNH0.2X3q-lMD_KcwwbCfcIwDOaBt3Zu0_2f7cx2hFnjoADM";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: false,
    detectSessionInUrl: true,
    storage: sessionStorage, // força persistência mesmo se o localStorage estiver bloqueado
  },
});
