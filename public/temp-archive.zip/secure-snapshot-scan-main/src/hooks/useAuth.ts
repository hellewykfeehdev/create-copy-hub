import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

interface SubscriptionState {
  subscribed: boolean;
  status: string;
  subscription_end: string | null;
  features: Record<string, boolean>;
  plan?: string;
  badge?: string;
  level?: string;
}

export function useAuth() {
  const [session, setSession] = useState<any>(null);
  const [subscription, setSubscription] = useState<SubscriptionState>(() => {
    // Initialize from localStorage for instant access on navigation
    const cached = localStorage.getItem("subscription_active");
    if (cached === "true") {
      return {
        subscribed: true,
        status: "active",
        subscription_end: null,
        features: {},
        plan: localStorage.getItem("subscription_plan") || "pro",
        badge: "shield",
        level: "Full Protection",
      };
    }
    return {
      subscribed: false,
      status: "inactive",
      subscription_end: null,
      features: {},
    };
  });
  const [loading, setLoading] = useState(true);
  const [subscriptionLoaded, setSubscriptionLoaded] = useState(false);

  const checkSubscription = useCallback(async () => {
    const currentSession = session;
    if (!currentSession?.access_token) {
      console.log("[useAuth] No session for subscription check");
      setSubscriptionLoaded(true);
      return;
    }

    try {
      console.log("[useAuth] Checking subscription...");
      const { data, error } = await supabase.functions.invoke(
        "check-subscription",
        {
          headers: {
            Authorization: `Bearer ${currentSession.access_token}`,
          },
        }
      );

      if (error) {
        console.error("[useAuth] Subscription check error:", error);
        throw error;
      }

      console.log("[useAuth] Subscription response:", data);

      const isSubscribed = Boolean(data?.subscribed);
      const plan = data?.plan ?? (isSubscribed ? "pro" : undefined);

      const newSubscription: SubscriptionState = {
        subscribed: isSubscribed,
        status: data?.status ?? "inactive",
        subscription_end: data?.subscription_end ?? null,
        features: data?.features ?? {},
        plan,
        badge: data?.badge ?? (isSubscribed ? "shield" : undefined),
        level: data?.access_level ?? (isSubscribed ? "Full Protection" : undefined),
      };

      setSubscription(newSubscription);
      
      // Cache in localStorage for quick access on page navigation
      localStorage.setItem("subscription_active", isSubscribed ? "true" : "false");
      if (plan) {
        localStorage.setItem("subscription_plan", plan);
      }

    } catch (err) {
      console.error("[useAuth] checkSubscription error:", err);
      // On error, keep cached state if available
      const cached = localStorage.getItem("subscription_active");
      if (cached !== "true") {
        setSubscription({
          subscribed: false,
          status: "inactive",
          subscription_end: null,
          features: {},
        });
      }
    } finally {
      setSubscriptionLoaded(true);
    }
  }, [session]);

  useEffect(() => {
    let mounted = true;

    const init = async () => {
      const { data } = await supabase.auth.getSession();
      if (!mounted) return;

      setSession(data.session);
      
      // Only set loading false after session is determined
      // Subscription check happens separately
      setLoading(false);
    };

    init();

    const { data: listener } = supabase.auth.onAuthStateChange(
      async (_event, newSession) => {
        if (!mounted) return;

        setSession(newSession);

        if (!newSession) {
          setSubscription({
            subscribed: false,
            status: "inactive",
            subscription_end: null,
            features: {},
          });
          setSubscriptionLoaded(true);
          localStorage.removeItem("subscription_active");
          localStorage.removeItem("subscription_plan");
        }
      }
    );

    return () => {
      mounted = false;
      listener?.subscription.unsubscribe();
    };
  }, []);

  // Check subscription whenever session changes
  useEffect(() => {
    if (session?.access_token) {
      checkSubscription();
    } else if (!session && !loading) {
      setSubscriptionLoaded(true);
    }
  }, [session?.access_token, checkSubscription, session, loading]);

  const signOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setSubscription({
      subscribed: false,
      status: "inactive",
      subscription_end: null,
      features: {},
    });
    setSubscriptionLoaded(true);
    localStorage.removeItem("subscription_active");
    localStorage.removeItem("subscription_plan");
  };

  // Combined loading: true while auth OR subscription is still loading
  // But if we have cached subscription, consider it loaded
  const isFullyLoaded = !loading && (subscriptionLoaded || subscription.subscribed);

  return {
    session,
    user: session?.user ?? null,
    subscription,
    loading: !isFullyLoaded,
    checkingSubscription: !subscriptionLoaded,
    checkSubscription,
    signOut,
  };
}
