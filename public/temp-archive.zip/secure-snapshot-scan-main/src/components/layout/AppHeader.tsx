import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  LayoutDashboard, 
  Search, 
  History, 
  Settings, 
  LogOut,
  Menu
} from "lucide-react";
import UserBadge from "@/components/subscription/UserBadge";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SentriXLogo } from "@/components/brand/SentriXLogo";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { cn } from "@/lib/utils";

interface AppHeaderProps {
  showNav?: boolean;
  disableNav?: boolean;
}

export default function AppHeader({ showNav = true, disableNav = false }: AppHeaderProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { session, subscription, signOut } = useAuth();
  
  const userName = session?.user?.user_metadata?.full_name || 
                   subscription?.level || 
                   "User";

  const handleLogout = async () => {
    await signOut();
    toast.success("Signed out successfully");
    navigate("/auth");
  };

  const navItems = [
    { path: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/main", icon: Search, label: "Analyze" },
    { path: "/history", icon: History, label: "History" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sentrix-header">
      <div className="container flex h-14 items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div 
            className="flex items-center gap-2.5 cursor-pointer" 
            onClick={() => !disableNav && navigate("/dashboard")}
          >
            <SentriXLogo variant="icon" size="sm" showText={true} />
          </div>
          
          {subscription?.subscribed && (
            <div className="flex items-center gap-2">
              <UserBadge badge={subscription.badge} level={subscription.level} size="sm" />
              <Badge variant="outline" className="text-xs hidden md:inline-flex font-medium border-border/60">
                {subscription.level}
              </Badge>
            </div>
          )}
        </div>

        {/* Desktop Navigation */}
        {showNav && (
          <nav className="hidden sm:flex items-center gap-1">
            {navItems.map((item) => (
              <Button
                key={item.path}
                variant="ghost"
                size="sm"
                className={cn(
                  "gap-2 relative transition-all duration-200",
                  isActive(item.path) 
                    ? "text-primary bg-primary/10 hover:bg-primary/15" 
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
                onClick={() => navigate(item.path)}
                disabled={disableNav}
              >
                <item.icon className="h-4 w-4" />
                <span className="hidden lg:inline">{item.label}</span>
                {isActive(item.path) && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-0.5 bg-primary rounded-full" />
                )}
              </Button>
            ))}
            
            <div className="w-px h-6 bg-border/60 mx-1" />
            
            <ThemeToggle />
            
            {session && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleLogout}
                className="h-9 w-9 text-muted-foreground hover:text-foreground"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            )}
          </nav>
        )}

        {/* Mobile Navigation */}
        {showNav && (
          <div className="sm:hidden flex items-center gap-1">
            <ThemeToggle />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9">
                  <Menu className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {userName && (
                  <>
                    <div className="px-2 py-1.5 text-sm font-medium text-foreground">
                      {userName}
                    </div>
                    <DropdownMenuSeparator />
                  </>
                )}
                {navItems.map((item) => (
                  <DropdownMenuItem
                    key={item.path}
                    onClick={() => navigate(item.path)}
                    disabled={disableNav}
                    className={cn(
                      isActive(item.path) 
                        ? "bg-primary/10 text-primary" 
                        : ""
                    )}
                  >
                    <item.icon className="h-4 w-4 mr-2" />
                    {item.label}
                  </DropdownMenuItem>
                ))}
                {session && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>
    </header>
  );
}
