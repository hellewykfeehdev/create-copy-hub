import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Loader2, ShieldOff, Lock, Zap } from "lucide-react";
import { FULL_PROTECTION_PRODUCT, type BillingInterval } from "@/config/plans";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { SentriXLogo } from "@/components/brand/SentriXLogo";
import { ThemeToggle } from "@/components/theme/ThemeToggle";

interface PaywallModalProps {
  isOpen: boolean;
}

const PaywallModal = ({ isOpen }: PaywallModalProps) => {
  const { session, loading: authLoading } = useAuth();
  const [loading, setLoading] = useState(false);
  const [billingInterval, setBillingInterval] = useState<BillingInterval>("monthly");

  const handleCheckout = async () => {
    const priceId = billingInterval === "monthly"
      ? FULL_PROTECTION_PRODUCT.pricing.monthly.priceId
      : FULL_PROTECTION_PRODUCT.pricing.annual.priceId;

    setLoading(true);

    try {
      if (!session?.access_token) {
        toast.error("Authentication required. Please sign in again.");
        setLoading(false);
        return;
      }

      toast.loading("Redirecting to secure checkout...", { duration: 5000 });

      const { data, error } = await supabase.functions.invoke("create-checkout-session", {
        body: { priceId, returnOrigin: window.location.origin },
        headers: { Authorization: `Bearer ${session.access_token}` },
      });

      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error("No checkout URL received");
      }
    } catch (err: any) {
      console.error("Checkout error:", err);
      toast.dismiss();
      toast.error(err.message || "Failed to start checkout. Try again.");
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 text-primary animate-spin mb-3" />
        <p className="text-sm text-muted-foreground">Loading your account...</p>
      </div>
    );
  }

  if (!isOpen) return null;

  const { pricing, features } = FULL_PROTECTION_PRODUCT;
  const selectedPricing = billingInterval === "monthly" ? pricing.monthly : pricing.annual;

  return (
    <div className="fixed inset-0 z-[100] bg-background overflow-y-auto">
      {/* Background pattern */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,hsl(var(--border)/0.3)_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border)/0.3)_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-50" />
      
      {/* Header with logo and theme toggle */}
      <div className="fixed top-4 left-4 right-4 z-50 flex items-center justify-between">
        <SentriXLogo variant="icon" size="sm" showText={true} />
        <ThemeToggle />
      </div>
      
      <div className="relative min-h-screen flex flex-col items-center justify-center p-4 sm:p-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
          className="text-center mb-8 max-w-lg"
        >
          <div className="w-16 h-16 mx-auto mb-6 rounded-xl bg-muted/50 border border-border flex items-center justify-center">
            <ShieldOff className="w-8 h-8 text-muted-foreground" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-semibold mb-3 text-foreground tracking-tight">
            Protection Inactive
          </h1>
          <p className="text-muted-foreground leading-relaxed">
            Activate SentriX to start analyzing threats and protect yourself from digital attacks.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="w-full max-w-md"
        >
          {/* Billing Toggle */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex items-center rounded-full border border-border p-1 bg-muted/30">
              <button
                onClick={() => setBillingInterval("monthly")}
                className={cn(
                  "px-5 py-2 text-sm font-medium rounded-full transition-all",
                  billingInterval === "monthly"
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingInterval("annual")}
                className={cn(
                  "px-5 py-2 text-sm font-medium rounded-full transition-all flex items-center gap-2",
                  billingInterval === "annual"
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                Annual
                {billingInterval !== "annual" && (
                  <Badge variant="secondary" className="text-xs bg-success/10 text-success border-success/20">
                    Save 2mo
                  </Badge>
                )}
              </button>
            </div>
          </div>

          {/* Plan Card */}
          <div className="sentrix-card border-2 border-primary/30 p-6 sm:p-8">
            <div className="flex items-center gap-4 mb-5">
              <SentriXLogo variant="icon" size="md" showText={false} />
              <div>
                <h3 className="text-xl font-semibold text-foreground">{FULL_PROTECTION_PRODUCT.name}</h3>
                <p className="text-sm text-muted-foreground">{FULL_PROTECTION_PRODUCT.tagline}</p>
              </div>
            </div>

            <div className="mb-5">
              <span className="text-4xl font-bold text-foreground">${selectedPricing.price}</span>
              <span className="text-muted-foreground ml-1">
                /{billingInterval === "monthly" ? "month" : "year"}
              </span>
              {billingInterval === "annual" && (
                <Badge className="ml-2 bg-success/10 text-success border-success/20">
                  {pricing.annual.savings}
                </Badge>
              )}
            </div>

            <ul className="space-y-3 mb-8">
              {features.map((feature, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm">
                  <Check className="w-4 h-4 mt-0.5 flex-shrink-0 text-success" />
                  <span className="text-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <Button
              className="w-full h-12 text-base font-medium shadow-button hover:shadow-accent transition-all"
              onClick={handleCheckout}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Activate Now — ${selectedPricing.price}/{billingInterval === "monthly" ? "mo" : "yr"}
                </>
              )}
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-8 text-center max-w-md"
        >
          <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground mb-3">
            <span className="flex items-center gap-1.5">
              <Lock className="w-4 h-4" />
              Secure payment
            </span>
            <span className="flex items-center gap-1.5">
              <Check className="w-4 h-4" />
              Cancel anytime
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            14-day money-back guarantee. Powered by Stripe.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default PaywallModal;
