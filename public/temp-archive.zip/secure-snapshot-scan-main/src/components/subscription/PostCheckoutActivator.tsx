import { useEffect, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const PostCheckoutActivator = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const activatingRef = useRef(false);

  useEffect(() => {
    const checkout = searchParams.get("checkout");

    // Only run for checkout=success and prevent double-execution
    if (checkout !== "success" || activatingRef.current) return;
    activatingRef.current = true;

    const toastId = toast.loading("Ativando sua proteção... Aguarde um momento.");

    let attempts = 0;
    const maxAttempts = 20;
    const pollInterval = 2000; // 2 seconds between polls

    const tryActivate = async (): Promise<void> => {
      attempts++;
      console.log(`[PostCheckout] Attempt ${attempts}/${maxAttempts}`);

      try {
        // Get current session
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session?.access_token) {
          console.log("[PostCheckout] No session, retrying...");
          if (attempts < maxAttempts) {
            setTimeout(tryActivate, pollInterval);
          } else {
            toast.dismiss(toastId);
            toast.error("Sessão expirada. Faça login novamente.");
          }
          return;
        }

        // Call finalize-checkout to verify with Stripe and create DB record
        const { data, error } = await supabase.functions.invoke("finalize-checkout", {
          headers: { Authorization: `Bearer ${session.access_token}` },
        });

        console.log("[PostCheckout] Finalize response:", data, error);

        if (error) {
          console.error("[PostCheckout] Finalize error:", error);
          if (attempts < maxAttempts) {
            setTimeout(tryActivate, pollInterval);
          } else {
            toast.dismiss(toastId);
            toast.error("Erro ao verificar assinatura. Recarregue a página.");
          }
          return;
        }

        if (data?.subscribed) {
          // Success! Clear URL params and reload to show dashboard
          toast.dismiss(toastId);
          toast.success("Proteção ativada com sucesso! Bem-vindo ao plano completo.");

          // Clean URL parameters
          searchParams.delete("checkout");
          searchParams.delete("session_id");
          setSearchParams(searchParams, { replace: true });

          // Force page reload to refresh auth state and subscription
          setTimeout(() => {
            window.location.reload();
          }, 500);
        } else if (attempts < maxAttempts) {
          // Not yet subscribed, keep polling
          console.log("[PostCheckout] Not subscribed yet, polling...");
          setTimeout(tryActivate, pollInterval);
        } else {
          // Max attempts reached
          toast.dismiss(toastId);
          toast.error("Demorou um pouco para ativar. Recarregue a página em alguns segundos.");
          
          // Clean URL anyway
          searchParams.delete("checkout");
          searchParams.delete("session_id");
          setSearchParams(searchParams, { replace: true });
        }
      } catch (err) {
        console.error("[PostCheckout] Error:", err);
        if (attempts < maxAttempts) {
          setTimeout(tryActivate, pollInterval);
        } else {
          toast.dismiss(toastId);
          toast.error("Erro ao ativar. Tente recarregar a página.");
        }
      }
    };

    // Start polling after a short delay to let Stripe webhook settle
    setTimeout(tryActivate, 1000);

    // Cleanup
    return () => {
      activatingRef.current = false;
    };
  }, [searchParams, setSearchParams, navigate]);

  return null;
};
