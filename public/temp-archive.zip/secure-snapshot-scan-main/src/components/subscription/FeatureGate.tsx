import { ReactNode } from "react";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FeatureGateProps {
  children: ReactNode;
  hasAccess: boolean;
  onUpgrade: () => void;
  featureName?: string;
}

const FeatureGate = ({ children, hasAccess, onUpgrade, featureName = "this feature" }: FeatureGateProps) => {
  if (hasAccess) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      {/* Blurred content */}
      <div className="blur-sm pointer-events-none select-none opacity-50">
        {children}
      </div>
      
      {/* Overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm rounded-lg">
        <div className="text-center p-6 max-w-xs">
          <div className="w-12 h-12 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
            <Lock className="w-6 h-6 text-muted-foreground" />
          </div>
          <h3 className="font-semibold mb-2">Premium Feature</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Upgrade to Pro to unlock {featureName}
          </p>
          <Button onClick={onUpgrade} size="sm">
            Upgrade to Pro
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FeatureGate;
