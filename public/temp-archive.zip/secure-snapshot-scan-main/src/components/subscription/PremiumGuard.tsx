import { ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";
import PaywallModal from "@/components/subscription/PaywallModal";
import { Loader2 } from "lucide-react";

interface PremiumGuardProps {
  children: ReactNode;
}

export const PremiumGuard = ({ children }: PremiumGuardProps) => {
  const { loading, subscription, user } = useAuth();

  // Show loading spinner while checking auth/subscription
  // This prevents the paywall from flashing
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  // If user is subscribed, show the content immediately
  if (subscription?.subscribed) {
    return <>{children}</>;
  }

  // Only show paywall if definitely not subscribed after loading completes
  return <PaywallModal isOpen />;
};
