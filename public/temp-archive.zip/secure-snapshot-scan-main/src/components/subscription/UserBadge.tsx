import { Shield } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface UserBadgeProps {
  badge: string | null;
  level?: string | null;
  size?: "sm" | "md" | "lg";
  showTooltip?: boolean;
}

const sizeConfig = {
  sm: { wrapper: "w-6 h-6", icon: "w-3 h-3" },
  md: { wrapper: "w-8 h-8", icon: "w-4 h-4" },
  lg: { wrapper: "w-12 h-12", icon: "w-6 h-6" },
};

const UserBadge = ({ badge, level, size = "md", showTooltip = true }: UserBadgeProps) => {
  if (!badge) return null;

  const sizeStyles = sizeConfig[size];

  const BadgeElement = (
    <div
      className={`${sizeStyles.wrapper} bg-accent text-accent-foreground rounded-full flex items-center justify-center border-2 border-accent shadow-sm`}
    >
      <Shield className={sizeStyles.icon} />
    </div>
  );

  if (!showTooltip) return BadgeElement;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        {BadgeElement}
      </TooltipTrigger>
      <TooltipContent>
        <p className="font-medium">{level || "Full Protection"}</p>
      </TooltipContent>
    </Tooltip>
  );
};

export default UserBadge;
