import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Check, Loader2, Zap } from "lucide-react";
import { FULL_PROTECTION_PRODUCT, type BillingInterval } from "@/config/plans";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface PlanSelectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function PlanSelectionModal({ open, onOpenChange }: PlanSelectionModalProps) {
  const [loading, setLoading] = useState(false);
  const [billingInterval, setBillingInterval] = useState<BillingInterval>("monthly");

  const handleCheckout = async () => {
    const priceId = billingInterval === "monthly"
      ? FULL_PROTECTION_PRODUCT.pricing.monthly.priceId
      : FULL_PROTECTION_PRODUCT.pricing.annual.priceId;

    setLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        toast.error("Please sign in to subscribe");
        onOpenChange(false);
        return;
      }

      const { data, error } = await supabase.functions.invoke("create-checkout-session", {
        body: { priceId, returnOrigin: window.location.origin },
        headers: { Authorization: `Bearer ${session.access_token}` },
      });

      if (error) throw error;
      if (data?.url) window.location.href = data.url;
      else throw new Error("No checkout URL returned");
    } catch (err: any) {
      console.error("Checkout error:", err);
      toast.error(err.message || "Failed to start checkout");
    } finally {
      setLoading(false);
    }
  };

  const { pricing, features } = FULL_PROTECTION_PRODUCT;
  const selectedPricing = billingInterval === "monthly" ? pricing.monthly : pricing.annual;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md sentrix-card border-border/60">
        <DialogHeader className="text-center pb-2">
          <DialogTitle className="text-xl font-semibold">Activate SentriX Full</DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Choose your billing preference
          </DialogDescription>
        </DialogHeader>

        {/* Billing Toggle */}
        <div className="flex justify-center mb-5">
          <div className="inline-flex items-center rounded-full border border-border p-1 bg-muted/30">
            <button
              onClick={() => setBillingInterval("monthly")}
              className={cn(
                "px-4 py-1.5 text-sm font-medium rounded-full transition-all",
                billingInterval === "monthly"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingInterval("annual")}
              className={cn(
                "px-4 py-1.5 text-sm font-medium rounded-full transition-all flex items-center gap-2",
                billingInterval === "annual"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              Annual
              {billingInterval !== "annual" && (
                <Badge variant="secondary" className="text-xs bg-success/10 text-success">
                  Save
                </Badge>
              )}
            </button>
          </div>
        </div>

        {/* Plan Card */}
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-primary">
              <Shield className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{FULL_PROTECTION_PRODUCT.name}</h3>
              <p className="text-xs text-muted-foreground">{FULL_PROTECTION_PRODUCT.tagline}</p>
            </div>
          </div>

          <div className="mb-4">
            <span className="text-3xl font-bold text-foreground">${selectedPricing.price}</span>
            <span className="text-muted-foreground">
              /{billingInterval === "monthly" ? "month" : "year"}
            </span>
            {billingInterval === "annual" && (
              <Badge className="ml-2 bg-success/10 text-success text-xs">
                {pricing.annual.savings}
              </Badge>
            )}
          </div>

          <ul className="space-y-2 mb-5">
            {features.slice(0, 5).map((feature, idx) => (
              <li key={idx} className="flex items-start gap-2 text-sm">
                <Check className="w-4 h-4 text-success mt-0.5 flex-shrink-0" />
                <span className="text-foreground">{feature}</span>
              </li>
            ))}
          </ul>

          <Button
            className="w-full h-11 font-medium shadow-button hover:shadow-accent transition-all"
            onClick={() => handleCheckout()}
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Activate — ${selectedPricing.price}/{billingInterval === "monthly" ? "mo" : "yr"}
              </>
            )}
          </Button>
        </div>

        <p className="text-xs text-center text-muted-foreground pt-2">
          14-day money-back guarantee. Cancel anytime.
        </p>
      </DialogContent>
    </Dialog>
  );
}
