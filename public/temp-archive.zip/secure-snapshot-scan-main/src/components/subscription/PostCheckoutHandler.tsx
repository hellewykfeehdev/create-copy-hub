// components/subscription/PostCheckoutHandler.tsx
import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

export const PostCheckoutHandler = () => {
  const { checkSubscription } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    const checkout = searchParams.get("checkout");

    if (checkout === "success") {
      toast.success("Pagamento confirmado! Ativando sua proteção...");
      checkSubscription(); // Força atualização ANTES do PremiumGuard checar

      // Limpa URL
      searchParams.delete("checkout");
      searchParams.delete("session_id");
      setSearchParams(searchParams, { replace: true });
    }

    if (checkout === "canceled") {
      toast.info("Pagamento cancelado.");
      searchParams.delete("checkout");
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams, checkSubscription, setSearchParams]);

  return null; // Não renderiza nada
};
