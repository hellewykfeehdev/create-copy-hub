import { useTheme } from "@/components/theme/ThemeProvider";

// Centralized logo imports - replace these files to update branding everywhere
import logoLight from "@/assets/logo/sentrix-logo.png";
import logoDark from "@/assets/logo/sentrix-logo-dark.png";
import icon from "@/assets/logo/sentrix-icon.png";

interface SentriXLogoProps {
  variant?: "full" | "icon";
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  showText?: boolean;
}

const sizeMap = {
  sm: { logo: "h-6", icon: "h-6 w-6", text: "text-sm" },
  md: { logo: "h-8", icon: "h-8 w-8", text: "text-base" },
  lg: { logo: "h-10", icon: "h-10 w-10", text: "text-lg" },
  xl: { logo: "h-14", icon: "h-14 w-14", text: "text-xl" },
};

export function SentriXLogo({ 
  variant = "full", 
  size = "md", 
  className = "",
  showText = true 
}: SentriXLogoProps) {
  const { resolvedTheme } = useTheme();
  
  const sizes = sizeMap[size];
  const logoSrc = resolvedTheme === "dark" ? logoDark : logoLight;

  if (variant === "icon") {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <img 
          src={icon} 
          alt="SentriX" 
          className={`${sizes.icon} object-contain`}
        />
        {showText && (
          <span className={`font-semibold tracking-tight ${sizes.text}`}>
            SentriX
          </span>
        )}
      </div>
    );
  }

  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src={logoSrc} 
        alt="SentriX" 
        className={`${sizes.logo} object-contain`}
      />
    </div>
  );
}

// Export individual assets for direct usage if needed
export { logoLight, logoDark, icon };
