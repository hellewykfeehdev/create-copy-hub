import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Download, Eye, Shield, Image, Calendar, AlertTriangle, CheckCircle, AlertCircle, Copy, ExternalLink, BadgeCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

interface SavedShareImagesProps {
  userId?: string;
}

interface ShareImage {
  id: string;
  image_url: string;
  created_at: string;
  analysis_id: string;
  watermark_payload: {
    score?: number;
    category?: string;
    date?: string;
  } | null;
}

const SavedShareImages = ({ userId }: SavedShareImagesProps) => {
  const [images, setImages] = useState<ShareImage[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchImages = async () => {
      try {
        const { data, error } = await supabase
          .from("analysis_share_images")
          .select("*")
          .eq("user_id", userId)
          .order("created_at", { ascending: false })
          .limit(12);

        if (error) throw error;
        setImages((data as ShareImage[]) || []);
      } catch (error) {
        console.error("Error fetching share images:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchImages();
  }, [userId]);

  const handleDownload = async (image: ShareImage) => {
    try {
      const response = await fetch(image.image_url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `safewise-verified-${image.analysis_id.slice(0, 8)}.svg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast.success("Image downloaded");
    } catch (error) {
      console.error("Download error:", error);
      toast.error("Download failed");
    }
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    toast.success("Analysis ID copied");
  };

  const handleShare = async (image: ShareImage) => {
    const shareUrl = `${window.location.origin}/result?id=${image.analysis_id}`;
    await navigator.clipboard.writeText(shareUrl);
    toast.success("Share link copied to clipboard");
  };

  const handleViewDetails = (analysisId: string) => {
    navigate(`/result?id=${analysisId}`);
  };

  const getRiskIcon = (score?: number) => {
    if (score === undefined) return <AlertCircle className="h-4 w-4 text-muted-foreground" />;
    if (score >= 75) return <AlertTriangle className="h-4 w-4 text-destructive" />;
    if (score >= 40) return <AlertCircle className="h-4 w-4 text-warning" />;
    return <CheckCircle className="h-4 w-4 text-success" />;
  };

  const getRiskLabel = (score?: number) => {
    if (score === undefined) return "Unknown";
    if (score >= 75) return "High Risk";
    if (score >= 40) return "Medium Risk";
    return "Low Risk";
  };

  const getRiskBadgeClass = (score?: number) => {
    if (score === undefined) return "bg-muted text-muted-foreground";
    if (score >= 75) return "bg-destructive/10 text-destructive border-destructive/20";
    if (score >= 40) return "bg-warning/10 text-warning border-warning/20";
    return "bg-success/10 text-success border-success/20";
  };

  const shortenId = (id: string) => id.slice(0, 8).toUpperCase();

  if (!userId) return null;

  if (loading) {
    return (
      <Card className="border-border/50 shadow-sm">
        <CardContent className="py-12">
          <div className="flex flex-col items-center justify-center gap-3">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <p className="text-sm text-muted-foreground">Loading saved images...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (images.length === 0) {
    return null;
  }

  return (
    <TooltipProvider>
      <Card className="border-border/50 shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-lg">Saved Images</CardTitle>
                <CardDescription className="text-xs">
                  Verified analysis images for sharing
                </CardDescription>
              </div>
            </div>
            <span className="text-xs text-muted-foreground">{images.length} images</span>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Image Grid */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {images.map((image) => (
              <div
                key={image.id}
                className="group relative overflow-hidden rounded-lg border border-border/50 bg-card transition-all hover:border-primary/30 hover:shadow-md"
              >
                {/* Image Preview */}
                <div className="relative aspect-video bg-muted/30 p-2">
                  <img
                    src={image.image_url}
                    alt="Analysis verification"
                    className="h-full w-full object-contain"
                  />
                  
                  {/* Verified Badge Overlay */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-primary/90 px-2 py-1 text-[10px] font-medium text-primary-foreground shadow-sm">
                        <BadgeCheck className="h-3 w-3" />
                        <span>VERIFIED</span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="left" className="max-w-[260px] text-xs">
                      This image was cryptographically generated and verified by SAFEWISE. Any modification invalidates authenticity.
                    </TooltipContent>
                  </Tooltip>
                </div>

                {/* Card Content */}
                <div className="p-3 space-y-3">
                  {/* Risk Badge & Score */}
                  <div className="flex items-center justify-between">
                    <div className={`flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-xs font-medium ${getRiskBadgeClass(image.watermark_payload?.score)}`}>
                      {getRiskIcon(image.watermark_payload?.score)}
                      <span>{getRiskLabel(image.watermark_payload?.score)}</span>
                    </div>
                    {image.watermark_payload?.score !== undefined && (
                      <span className="text-lg font-semibold tabular-nums">
                        {image.watermark_payload.score}%
                      </span>
                    )}
                  </div>

                  {/* Category */}
                  {image.watermark_payload?.category && (
                    <p className="text-xs text-muted-foreground truncate">
                      {image.watermark_payload.category}
                    </p>
                  )}

                  {/* Metadata Row */}
                  <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      <span>{format(new Date(image.created_at), "MMM d, yyyy")}</span>
                    </div>
                    
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          onClick={() => handleCopyId(image.analysis_id)}
                          className="flex items-center gap-1 rounded px-1.5 py-0.5 font-mono hover:bg-muted transition-colors"
                        >
                          <span>#{shortenId(image.analysis_id)}</span>
                          <Copy className="h-2.5 w-2.5" />
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>Copy Analysis ID</TooltipContent>
                    </Tooltip>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-1 border-t border-border/50">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="flex-1 h-8 text-xs">
                          <Eye className="h-3.5 w-3.5 mr-1" />
                          Preview
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Shield className="h-5 w-5 text-primary" />
                            SAFEWISE Verified Image
                          </DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="relative rounded-lg border bg-muted/30 p-4">
                            <img
                              src={image.image_url}
                              alt="Analysis verification"
                              className="w-full rounded"
                            />
                            <div className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground">
                              <BadgeCheck className="h-4 w-4" />
                              <span>SAFEWISE VERIFIED</span>
                            </div>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button
                              onClick={() => handleDownload(image)}
                              className="flex-1"
                            >
                              <Download className="h-4 w-4 mr-2" />
                              Download SVG
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => handleShare(image)}
                              className="flex-1"
                            >
                              <Copy className="h-4 w-4 mr-2" />
                              Copy Share Link
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 text-xs"
                      onClick={() => handleDownload(image)}
                    >
                      <Download className="h-3.5 w-3.5" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 text-xs"
                      onClick={() => handleShare(image)}
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 text-xs"
                      onClick={() => handleViewDetails(image.analysis_id)}
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Trust Footer */}
          <div className="flex items-start gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <BadgeCheck className="h-4 w-4 text-primary" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-foreground">SAFEWISE Verified Images</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                All images are cryptographically generated and protected against tampering. 
                Each image contains embedded verification data that ensures authenticity and auditability.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default SavedShareImages;
