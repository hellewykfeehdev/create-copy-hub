import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface DMInputModeProps {
  text: string;
  onTextChange: (value: string) => void;
}

const DMInputMode = ({ text, onTextChange }: DMInputModeProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="dm-text" className="text-sm font-medium">
        Message Content <span className="text-destructive">*</span>
      </Label>
      <Textarea
        id="dm-text"
        placeholder="Paste the message or conversation here (WhatsApp, Slack, SMS, etc.)"
        value={text}
        onChange={(e) => onTextChange(e.target.value)}
        rows={10}
        maxLength={5000}
        className="resize-none"
      />
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Include timestamps and sender names if available for better analysis.
        </p>
        <p className="text-xs text-muted-foreground">
          {text.length}/5000
        </p>
      </div>
    </div>
  );
};

export default DMInputMode;
