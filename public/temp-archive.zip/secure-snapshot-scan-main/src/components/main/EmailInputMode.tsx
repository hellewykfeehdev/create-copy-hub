import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface EmailInputModeProps {
  subject: string;
  sender: string;
  body: string;
  onSubjectChange: (value: string) => void;
  onSenderChange: (value: string) => void;
  onBodyChange: (value: string) => void;
}

const EmailInputMode = ({
  subject,
  sender,
  body,
  onSubjectChange,
  onSenderChange,
  onBodyChange,
}: EmailInputModeProps) => {
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="email-subject" className="text-sm font-medium">
            Subject <span className="text-muted-foreground font-normal">(optional)</span>
          </Label>
          <Input
            id="email-subject"
            placeholder="e.g., Urgent: Account Verification"
            value={subject}
            onChange={(e) => onSubjectChange(e.target.value)}
            maxLength={200}
            className="h-10"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email-sender" className="text-sm font-medium">
            Sender <span className="text-muted-foreground font-normal">(optional)</span>
          </Label>
          <Input
            id="email-sender"
            type="email"
            placeholder="e.g., support@suspicious-domain.com"
            value={sender}
            onChange={(e) => onSenderChange(e.target.value)}
            maxLength={100}
            className="h-10"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email-body" className="text-sm font-medium">
          Email Body <span className="text-destructive">*</span>
        </Label>
        <Textarea
          id="email-body"
          placeholder="Paste the email content here..."
          value={body}
          onChange={(e) => onBodyChange(e.target.value)}
          rows={8}
          maxLength={5000}
          className="resize-none"
        />
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            We analyze the message content, not your inbox.
          </p>
          <p className="text-xs text-muted-foreground">
            {body.length}/5000
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmailInputMode;
