import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Upload, X, Image, Loader2, Check, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface ImageOcrUploadProps {
  ocrText: string;
  ocrConfirmed: boolean;
  onOcrComplete: (text: string) => void;
  onOcrConfirm: () => void;
  onOcrClear: () => void;
  onOcrTextEdit: (text: string) => void;
}

const ImageOcrUpload = ({
  ocrText,
  ocrConfirmed,
  onOcrComplete,
  onOcrConfirm,
  onOcrClear,
  onOcrTextEdit,
}: ImageOcrUploadProps) => {
  const [extracting, setExtracting] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const { user } = useAuth();

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file
    const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB
    const isValidType = ["image/png", "image/jpeg", "image/jpg"].includes(file.type);

    if (!isValidSize) {
      toast.error("Image is too large (max 10MB)");
      return;
    }

    if (!isValidType) {
      toast.error("Please upload a PNG or JPG image");
      return;
    }

    setSelectedImage(file);
    await extractTextFromImage(file);
  };

  const extractTextFromImage = async (file: File) => {
    if (!user?.id) {
      toast.error("Please sign in to use OCR");
      return;
    }

    setExtracting(true);

    try {
      // Convert file to base64
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve, reject) => {
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      const base64Data = await base64Promise;

      // Call our secure edge function instead of external API
      const { data, error } = await supabase.functions.invoke("image-ocr", {
        body: {
          userId: user.id,
          imageBase64: base64Data
        }
      });

      if (error) {
        throw new Error(error.message || "OCR service failed");
      }

      const extractedText = data?.ocr?.extracted_text || "";

      if (extractedText) {
        onOcrComplete(extractedText);
        toast.success("Text extracted successfully");
      } else {
        toast.error("No text found in image");
      }
    } catch (error: any) {
      console.error("OCR error:", error);
      toast.error(error.message || "Failed to extract text from image");
    } finally {
      setExtracting(false);
    }
  };

  const handleClear = () => {
    setSelectedImage(null);
    onOcrClear();
  };

  // If OCR text exists and is confirmed, show confirmation state
  if (ocrText && ocrConfirmed) {
    return (
      <div className="space-y-3 p-4 bg-success/10 border border-success/20 rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Check className="h-4 w-4 text-success" />
            <span className="text-sm font-medium text-success">Text confirmed for analysis</span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleClear}>
            <X className="h-4 w-4 mr-1" />
            Clear
          </Button>
        </div>
        <p className="text-xs text-muted-foreground line-clamp-2">{ocrText}</p>
      </div>
    );
  }

  // If OCR text exists but not confirmed, show editable text
  if (ocrText && !ocrConfirmed) {
    return (
      <div className="space-y-4 p-4 bg-muted/50 border border-border rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Image className="h-4 w-4 text-accent" />
            <span className="text-sm font-medium">Extracted Text</span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleClear}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-start gap-2 p-3 bg-warning/10 border border-warning/20 rounded-md">
          <AlertCircle className="h-4 w-4 text-warning mt-0.5 flex-shrink-0" />
          <p className="text-xs text-warning-foreground">
            Images are converted to text for accurate analysis. Review and edit if needed, then confirm.
          </p>
        </div>

        <div className="space-y-2">
          <Label className="text-sm font-medium">Review Extracted Text</Label>
          <Textarea
            value={ocrText}
            onChange={(e) => onOcrTextEdit(e.target.value)}
            rows={6}
            className="resize-none"
            placeholder="Extracted text will appear here..."
          />
          <p className="text-xs text-muted-foreground">
            {ocrText.length} characters extracted
          </p>
        </div>

        <Button onClick={onOcrConfirm} className="w-full" variant="secondary">
          <Check className="h-4 w-4 mr-2" />
          Confirm Text for Analysis
        </Button>
      </div>
    );
  }

  // Default: Upload state
  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium flex items-center gap-2">
        <Image className="h-4 w-4" />
        Upload Screenshot <span className="text-muted-foreground font-normal">(optional)</span>
      </Label>
      
      <div className="border-2 border-dashed border-border/60 rounded-lg p-4 text-center hover:border-accent/50 transition-colors cursor-pointer bg-muted/30">
        <input
          type="file"
          id="ocr-upload"
          className="hidden"
          accept="image/png,image/jpeg,image/jpg"
          onChange={handleImageSelect}
          disabled={extracting}
        />
        <label htmlFor="ocr-upload" className="cursor-pointer">
          {extracting ? (
            <div className="flex flex-col items-center gap-2 py-2">
              <Loader2 className="h-6 w-6 animate-spin text-accent" />
              <p className="text-sm text-muted-foreground">Extracting text...</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2 py-2">
              <Upload className="h-6 w-6 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                Click to upload screenshot
              </p>
              <p className="text-xs text-muted-foreground">
                PNG, JPG (max 10MB)
              </p>
            </div>
          )}
        </label>
      </div>
    </div>
  );
};

export default ImageOcrUpload;
