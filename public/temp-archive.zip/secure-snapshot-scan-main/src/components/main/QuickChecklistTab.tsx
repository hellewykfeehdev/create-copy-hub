import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const CHECKLIST_QUESTIONS = [
  { key: "pressure_to_pay", label: "Were you pressured to send money or act quickly?" },
  { key: "guaranteed_refund", label: "Is there a guaranteed refund or 'too good to be true' promise?" },
  { key: "stranger_request", label: "Did the request come from a stranger or unknown number?" },
  { key: "personal_info_requested", label: "Were you asked for personal information (passwords, OTP, bank details)?" },
  { key: "suspicious_link", label: "Does the message contain a suspicious link or attachment?" },
  { key: "grammar_errors", label: "Are there unusual grammar errors or formatting?" },
];

interface QuickChecklistTabProps {
  userId?: string;
}

const QuickChecklistTab = ({ userId }: QuickChecklistTabProps) => {
  const [answers, setAnswers] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleToggle = (key: string) => {
    setAnswers(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleAnalyze = async () => {
    if (!userId) {
      toast.error("Please sign in to use this feature");
      navigate("/auth");
      return;
    }

    const answeredCount = Object.values(answers).filter(Boolean).length;
    if (answeredCount === 0) {
      toast.error("Please answer at least one question");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          userId,
          checklist: answers,
        },
      });

      if (error) throw error;

      navigate("/result", { state: { analysis: data.result, analysisId: data.analysisId } });
    } catch (error: any) {
      console.error("Analysis error:", error);
      toast.error(error.message || "Failed to analyze. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Risk Check</CardTitle>
        <CardDescription>
          Answer these questions to get an instant risk assessment
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {CHECKLIST_QUESTIONS.map((question) => (
          <div
            key={question.key}
            className="flex items-center justify-between space-x-2 p-4 rounded-lg border hover:bg-muted/50 transition-colors duration-fast"
          >
            <Label htmlFor={question.key} className="flex-1 cursor-pointer">
              {question.label}
            </Label>
            <Switch
              id={question.key}
              checked={answers[question.key] || false}
              onCheckedChange={() => handleToggle(question.key)}
            />
          </div>
        ))}

        <Button
          onClick={handleAnalyze}
          disabled={loading}
          className="w-full mt-6"
          size="lg"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing...
            </>
          ) : (
            "Analyze Checklist"
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default QuickChecklistTab;
