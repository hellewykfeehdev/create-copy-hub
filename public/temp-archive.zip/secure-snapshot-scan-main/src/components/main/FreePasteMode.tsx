import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface FreePasteModeProps {
  text: string;
  onTextChange: (value: string) => void;
}

const FreePasteMode = ({ text, onTextChange }: FreePasteModeProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="free-text" className="text-sm font-medium">
        Content <span className="text-destructive">*</span>
      </Label>
      <Textarea
        id="free-text"
        placeholder="Paste any message exactly as received."
        value={text}
        onChange={(e) => onTextChange(e.target.value)}
        rows={10}
        maxLength={5000}
        className="resize-none"
      />
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Copy and paste the exact content for accurate analysis.
        </p>
        <p className="text-xs text-muted-foreground">
          {text.length}/5000
        </p>
      </div>
    </div>
  );
};

export default FreePasteMode;
