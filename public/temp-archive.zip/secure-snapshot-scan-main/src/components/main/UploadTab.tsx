import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Upload, X, File, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface UploadTabProps {
  userId?: string;
}

const UploadTab = ({ userId }: UploadTabProps) => {
  const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const navigate = useNavigate();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const validFiles = selectedFiles.filter(file => {
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB
      const isValidType = ['image/png', 'image/jpeg', 'image/jpg', 'application/pdf'].includes(file.type);
      
      if (!isValidSize) toast.error(`${file.name} is too large (max 10MB)`);
      if (!isValidType) toast.error(`${file.name} has unsupported format`);
      
      return isValidSize && isValidType;
    });

    if (files.length + validFiles.length > 3) {
      toast.error("Maximum 3 files allowed");
      return;
    }

    setFiles(prev => [...prev, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleAnalyze = async () => {
    if (!userId) {
      toast.error("Please sign in to use this feature");
      navigate("/auth");
      return;
    }

    if (!text.trim() && files.length === 0) {
      toast.error("Please provide text or upload files");
      return;
    }

    setUploading(true);
    const uploadedUrls: string[] = [];

    try {
      // Upload files to storage
      for (const file of files) {
        const fileName = `${Date.now()}_${file.name}`;
        const filePath = `${userId}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from("uploads")
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from("uploads")
          .getPublicUrl(filePath);

        uploadedUrls.push(publicUrl);

        // Save to uploads_temp
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7); // 7 days

        await supabase.from("uploads_temp").insert({
          user_id: userId,
          file_url: publicUrl,
          expires_at: expiresAt.toISOString(),
        });
      }

      setUploading(false);
      setAnalyzing(true);

      // Call analysis function
      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          userId,
          text: text.trim() || undefined,
          files: uploadedUrls.length > 0 ? uploadedUrls : undefined,
        },
      });

      if (error) throw error;

      navigate("/result", { state: { analysis: data.result, analysisId: data.analysisId } });
    } catch (error: any) {
      console.error("Analysis error:", error);
      toast.error(error.message || "Failed to analyze. Please try again.");
    } finally {
      setUploading(false);
      setAnalyzing(false);
    }
  };

  const isLoading = uploading || analyzing;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload & Analyze</CardTitle>
        <CardDescription>
          Upload screenshots, PDFs, or paste suspicious text/links
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Paste Message or Link</Label>
          <Textarea
            placeholder="Paste suspicious message, email, or link here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={6}
            maxLength={5000}
          />
          <p className="text-xs text-muted-foreground text-right">
            {text.length}/5000
          </p>
        </div>

        <div className="space-y-2">
          <Label>Upload Files</Label>
          <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-accent transition-colors duration-fast cursor-pointer">
            <input
              type="file"
              id="file-upload"
              className="hidden"
              multiple
              accept="image/png,image/jpeg,image/jpg,application/pdf"
              onChange={handleFileChange}
              disabled={files.length >= 3}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                Click to upload or drag and drop
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                PNG, JPG, PDF (max 10MB, up to 3 files)
              </p>
            </label>
          </div>

          {files.length > 0 && (
            <div className="space-y-2 mt-4">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-muted rounded-lg"
                >
                  <div className="flex items-center gap-2">
                    <File className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm truncate max-w-xs">{file.name}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeFile(index)}
                    disabled={isLoading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <Button
          onClick={handleAnalyze}
          disabled={isLoading || (!text.trim() && files.length === 0)}
          className="w-full"
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {uploading ? "Uploading..." : "Analyzing..."}
            </>
          ) : (
            "Analyze Now"
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default UploadTab;
