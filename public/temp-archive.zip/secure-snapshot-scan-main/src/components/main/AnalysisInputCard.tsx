import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2, Mail, MessageCircle, FileText, Shield } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import EmailInputMode from "./EmailInputMode";
import DMInputMode from "./DMInputMode";
import FreePasteMode from "./FreePasteMode";
import ImageOcrUpload from "./ImageOcrUpload";

interface AnalysisInputCardProps {
  userId?: string;
}

export type InputMode = "email" | "dm" | "free";

const AnalysisInputCard = ({ userId }: AnalysisInputCardProps) => {
  const [mode, setMode] = useState<InputMode>("email");
  const [analyzing, setAnalyzing] = useState(false);
  const navigate = useNavigate();

  // Email mode state
  const [emailSubject, setEmailSubject] = useState("");
  const [emailSender, setEmailSender] = useState("");
  const [emailBody, setEmailBody] = useState("");

  // DM mode state
  const [dmText, setDmText] = useState("");

  // Free paste mode state
  const [freeText, setFreeText] = useState("");

  // OCR extracted text
  const [ocrText, setOcrText] = useState("");
  const [ocrConfirmed, setOcrConfirmed] = useState(false);

  const getAnalysisText = (): string => {
    // If OCR text is present and confirmed, use it
    if (ocrText && ocrConfirmed) {
      return ocrText;
    }

    switch (mode) {
      case "email":
        const parts: string[] = [];
        if (emailSubject.trim()) parts.push(`Subject: ${emailSubject.trim()}`);
        if (emailSender.trim()) parts.push(`From: ${emailSender.trim()}`);
        if (emailBody.trim()) parts.push(`Body:\n${emailBody.trim()}`);
        return parts.join("\n");
      case "dm":
        return dmText.trim();
      case "free":
        return freeText.trim();
      default:
        return "";
    }
  };

  const canAnalyze = (): boolean => {
    if (ocrText && ocrConfirmed) return true;
    
    switch (mode) {
      case "email":
        return emailBody.trim().length > 0;
      case "dm":
        return dmText.trim().length > 0;
      case "free":
        return freeText.trim().length > 0;
      default:
        return false;
    }
  };

  const handleOcrComplete = (extractedText: string) => {
    setOcrText(extractedText);
    setOcrConfirmed(false);
  };

  const handleOcrConfirm = () => {
    setOcrConfirmed(true);
  };

  const handleOcrClear = () => {
    setOcrText("");
    setOcrConfirmed(false);
  };

  const handleAnalyze = async () => {
    if (!userId) {
      toast.error("Please sign in to use this feature");
      navigate("/auth");
      return;
    }

    const textToAnalyze = getAnalysisText();
    if (!textToAnalyze) {
      toast.error("Please provide content to analyze");
      return;
    }

    setAnalyzing(true);

    try {
      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          userId,
          text: textToAnalyze,
        },
      });

      if (error) throw error;

      navigate("/result", { state: { analysis: data.result, analysisId: data.analysisId } });
    } catch (error: any) {
      console.error("Analysis error:", error);
      toast.error(error.message || "Failed to analyze. Please try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <Card className="border-border/50 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-accent" />
          <CardTitle className="text-lg">Analyze Message</CardTitle>
        </div>
        <CardDescription className="text-sm">
          Paste or upload suspicious content for instant risk analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Image OCR Upload Section */}
        <ImageOcrUpload
          ocrText={ocrText}
          ocrConfirmed={ocrConfirmed}
          onOcrComplete={handleOcrComplete}
          onOcrConfirm={handleOcrConfirm}
          onOcrClear={handleOcrClear}
          onOcrTextEdit={setOcrText}
        />

        {/* Input Mode Tabs - Only show if no OCR text or not confirmed */}
        {(!ocrText || !ocrConfirmed) && (
          <Tabs value={mode} onValueChange={(v) => setMode(v as InputMode)} className="w-full">
            <TabsList className="grid w-full grid-cols-3 h-11">
              <TabsTrigger value="email" className="gap-2 text-xs sm:text-sm">
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">Email</span>
              </TabsTrigger>
              <TabsTrigger value="dm" className="gap-2 text-xs sm:text-sm">
                <MessageCircle className="h-4 w-4" />
                <span className="hidden sm:inline">DM</span>
              </TabsTrigger>
              <TabsTrigger value="free" className="gap-2 text-xs sm:text-sm">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">Free Paste</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="email" className="mt-4">
              <EmailInputMode
                subject={emailSubject}
                sender={emailSender}
                body={emailBody}
                onSubjectChange={setEmailSubject}
                onSenderChange={setEmailSender}
                onBodyChange={setEmailBody}
              />
            </TabsContent>

            <TabsContent value="dm" className="mt-4">
              <DMInputMode
                text={dmText}
                onTextChange={setDmText}
              />
            </TabsContent>

            <TabsContent value="free" className="mt-4">
              <FreePasteMode
                text={freeText}
                onTextChange={setFreeText}
              />
            </TabsContent>
          </Tabs>
        )}

        {/* Analyze Button */}
        <Button
          onClick={handleAnalyze}
          disabled={analyzing || !canAnalyze()}
          className="w-full h-12 text-base font-medium"
          size="lg"
        >
          {analyzing ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Analyzing...
            </>
          ) : (
            "Analyze Now"
          )}
        </Button>

        {/* Trust Note */}
        <p className="text-xs text-muted-foreground text-center">
          Your data is processed securely and never stored beyond analysis.
        </p>
      </CardContent>
    </Card>
  );
};

export default AnalysisInputCard;
