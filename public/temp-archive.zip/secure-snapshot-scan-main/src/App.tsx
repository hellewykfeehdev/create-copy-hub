import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme/ThemeProvider";

import ProtectedRoute from "@/components/ProtectedRoute";
import { PremiumGuard } from "@/components/subscription/PremiumGuard";
import { PostCheckoutActivator } from "@/components/subscription/PostCheckoutActivator";

import Landing from "./pages/Landing";
import Auth from "./pages/Auth";
import Onboarding from "./pages/Onboarding";
import Dashboard from "./pages/Dashboard";
import Main from "./pages/Main";
import Result from "./pages/Result";
import History from "./pages/History";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider defaultTheme="system" storageKey="sentrix-ui-theme">
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Landing />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/onboarding" element={<Onboarding />} />

            {/* Dashboard (checkout-aware + premium) */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <>
                    <PostCheckoutActivator />
                    <PremiumGuard>
                      <Dashboard />
                    </PremiumGuard>
                  </>
                </ProtectedRoute>
              }
            />

            {/* Premium routes */}
            <Route
              path="/main"
              element={
                <ProtectedRoute>
                  <PremiumGuard>
                    <Main />
                  </PremiumGuard>
                </ProtectedRoute>
              }
            />

            <Route
              path="/history"
              element={
                <ProtectedRoute>
                  <PremiumGuard>
                    <History />
                  </PremiumGuard>
                </ProtectedRoute>
              }
            />

            <Route
              path="/settings"
              element={
                <ProtectedRoute>
                  <PremiumGuard>
                    <Settings />
                  </PremiumGuard>
                </ProtectedRoute>
              }
            />

            {/* Result */}
            <Route
              path="/result"
              element={
                <ProtectedRoute>
                  <Result />
                </ProtectedRoute>
              }
            />

            {/* 404 */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
